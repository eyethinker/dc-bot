"""
Configuration settings for the Discord bot
Handles environment variables and default settings
"""

import os
import logging

# Configure logging
logger = logging.getLogger(__name__)

# Discord Bot Configuration
BOT_TOKEN = os.getenv('DISCORD_BOT_TOKEN', 'your_bot_token_here')
COMMAND_PREFIX = os.getenv('COMMAND_PREFIX', '.')

# Validate required environment variables
if BOT_TOKEN == 'your_bot_token_here':
    logger.warning("DISCORD_BOT_TOKEN not set in environment variables!")
    logger.warning("Please set your Discord bot token in the Replit secrets tab")

# Bot Settings
MAX_CREDITS_PER_USER = int(os.getenv('MAX_CREDITS_PER_USER', '1000000'))
DAILY_CREDITS_AMOUNT = int(os.getenv('DAILY_CREDITS_AMOUNT', '1500'))
WORK_CREDITS_AMOUNT = int(os.getenv('WORK_CREDITS_AMOUNT', '500'))
FLAG_GAME_REWARD = int(os.getenv('FLAG_GAME_REWARD', '100'))

# Cooldown Settings (in seconds)
DAILY_COOLDOWN = int(os.getenv('DAILY_COOLDOWN', '86400'))  # 24 hours
WORK_COOLDOWN = int(os.getenv('WORK_COOLDOWN', '3600'))     # 1 hour
FLAG_GAME_TIMEOUT = int(os.getenv('FLAG_GAME_TIMEOUT', '30'))  # 30 seconds

# Web Server Settings
WEB_PORT = int(os.getenv('PORT', '5000'))
WEB_HOST = os.getenv('HOST', '0.0.0.0')

# Data Settings
AUTO_SAVE_INTERVAL = int(os.getenv('AUTO_SAVE_INTERVAL', '300'))  # 5 minutes
BACKUP_ENABLED = os.getenv('BACKUP_ENABLED', 'true').lower() == 'true'

# Logging Settings
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').upper()

# Development/Debug Settings
DEBUG_MODE = os.getenv('DEBUG_MODE', 'false').lower() == 'true'

logger.info("Configuration loaded successfully")

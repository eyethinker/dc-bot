"""
Database manager for Discord bot
Handles database operations with PostgreSQL
"""

import logging
from datetime import datetime
from typing import Dict, Optional
from models import app, db, User, UserTimestamp

logger = logging.getLogger(__name__)


class DatabaseManager:
    """Manages database operations for the Discord bot"""
    
    def __init__(self):
        self.app = app
        self._init_db()
        logger.info("DatabaseManager initialized with PostgreSQL")
    
    def _init_db(self):
        """Initialize database tables"""
        with self.app.app_context():
            try:
                db.create_all()
                logger.info("Database tables initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize database: {e}")
                raise
    
    def _get_or_create_user(self, user_id: str) -> User:
        """Get existing user or create new one"""
        with self.app.app_context():
            user = User.query.filter_by(id=user_id).first()
            if not user:
                user = User()
                user.id = user_id
                user.credits = 0
                db.session.add(user)
                db.session.commit()
                logger.debug(f"Created new user: {user_id}")
            return user
    
    # Credits management
    def get_credits(self, user_id: str) -> int:
        """Get user's credit balance"""
        with self.app.app_context():
            user = self._get_or_create_user(user_id)
            return user.credits
    
    def set_credits(self, user_id: str, amount: int) -> None:
        """Set user's credit balance"""
        with self.app.app_context():
            # Get fresh user instance within this session
            user = User.query.filter_by(id=user_id).first()
            if not user:
                user = User()
                user.id = user_id
                user.credits = 0
                db.session.add(user)
                db.session.flush()
            
            user.credits = max(0, amount)
            user.updated_at = datetime.utcnow()
            db.session.commit()
            logger.debug(f"Set credits for {user_id}: {amount}")
    
    def add_credits(self, user_id: str, amount: int) -> int:
        """Add credits to user's balance (can be negative)"""
        with self.app.app_context():
            # Get fresh user instance within this session
            user = User.query.filter_by(id=user_id).first()
            if not user:
                user = User()
                user.id = user_id
                user.credits = 0
                user.bank_credits = 0
                user.has_shield = False
                db.session.add(user)
                db.session.flush()  # Ensure user is in session
            
            current = user.credits
            new_amount = max(0, current + amount)
            user.credits = new_amount
            user.updated_at = datetime.utcnow()
            db.session.commit()
            logger.debug(f"Added {amount} credits to {user_id}: {current} -> {new_amount}")
            return new_amount
    
    def get_all_credits(self) -> Dict[str, int]:
        """Get all users' credit data"""
        with self.app.app_context():
            users = User.query.all()
            return {user.id: user.credits for user in users}
    
    # Timestamp management
    def _get_timestamp(self, user_id: str, timestamp_type: str) -> Optional[datetime]:
        """Get timestamp for user and type"""
        with self.app.app_context():
            timestamp_record = UserTimestamp.query.filter_by(
                user_id=user_id, 
                timestamp_type=timestamp_type
            ).first()
            
            if timestamp_record:
                return timestamp_record.timestamp
            return None
    
    def _set_timestamp(self, user_id: str, timestamp_type: str, timestamp: datetime) -> None:
        """Set timestamp for user and type"""
        with self.app.app_context():
            # Ensure user exists
            self._get_or_create_user(user_id)
            
            # Get or create timestamp record
            timestamp_record = UserTimestamp.query.filter_by(
                user_id=user_id, 
                timestamp_type=timestamp_type
            ).first()
            
            if timestamp_record:
                timestamp_record.timestamp = timestamp
            else:
                timestamp_record = UserTimestamp()
                timestamp_record.user_id = user_id
                timestamp_record.timestamp_type = timestamp_type
                timestamp_record.timestamp = timestamp
                db.session.add(timestamp_record)
            
            db.session.commit()
            logger.debug(f"Set {timestamp_type} timestamp for {user_id}: {timestamp}")
    
    def get_daily_timestamp(self, user_id: str) -> Optional[datetime]:
        """Get user's last daily claim timestamp"""
        return self._get_timestamp(user_id, "daily")
    
    def set_daily_timestamp(self, user_id: str, timestamp: datetime) -> None:
        """Set user's daily claim timestamp"""
        self._set_timestamp(user_id, "daily", timestamp)
    
    def get_work_timestamp(self, user_id: str) -> Optional[datetime]:
        """Get user's last work timestamp"""
        return self._get_timestamp(user_id, "work")
    
    def set_work_timestamp(self, user_id: str, timestamp: datetime) -> None:
        """Set user's work timestamp"""
        self._set_timestamp(user_id, "work", timestamp)
    
    # User management
    def get_user_stats(self, user_id: str) -> Dict:
        """Get comprehensive user statistics"""
        with self.app.app_context():
            user = self._get_or_create_user(user_id)
            return {
                "credits": user.credits,
                "last_daily": self.get_daily_timestamp(user_id),
                "last_work": self.get_work_timestamp(user_id),
                "created_at": user.created_at,
                "updated_at": user.updated_at
            }
    
    def delete_user_data(self, user_id: str) -> bool:
        """Delete all data for a user"""
        with self.app.app_context():
            try:
                # Delete timestamps
                UserTimestamp.query.filter_by(user_id=user_id).delete()
                
                # Delete user
                user = User.query.filter_by(id=user_id).first()
                if user:
                    db.session.delete(user)
                
                db.session.commit()
                logger.info(f"Deleted all data for user {user_id}")
                return True
            except Exception as e:
                db.session.rollback()
                logger.error(f"Failed to delete user data for {user_id}: {e}")
                return False
    
    def get_total_users(self) -> int:
        """Get total number of users with data"""
        with self.app.app_context():
            return User.query.count()
    
    def get_total_credits_in_economy(self) -> int:
        """Get total credits across all users"""
        with self.app.app_context():
            wallet_result = db.session.query(db.func.sum(User.credits)).scalar() or 0
            bank_result = db.session.query(db.func.sum(User.bank_credits)).scalar() or 0
            return wallet_result + bank_result
    
    # Banking system methods
    def get_bank_credits(self, user_id: str) -> int:
        """Get user's bank credit balance"""
        with self.app.app_context():
            user = User.query.filter_by(id=user_id).first()
            if not user:
                return 0
            return user.bank_credits
    
    def deposit_to_bank(self, user_id: str, amount: int = None) -> tuple[int, int]:
        """Deposit credits from wallet to bank. Returns (deposited_amount, new_bank_balance)"""
        with self.app.app_context():
            user = User.query.filter_by(id=user_id).first()
            if not user:
                user = User()
                user.id = user_id
                user.credits = 0
                user.bank_credits = 0
                user.has_shield = False
                db.session.add(user)
                db.session.flush()
            
            if amount is None:  # Deposit all
                amount = user.credits
            else:
                amount = min(amount, user.credits)
            
            user.credits -= amount
            user.bank_credits += amount
            user.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.debug(f"User {user_id} deposited {amount} credits to bank")
            return amount, user.bank_credits
    
    def withdraw_from_bank(self, user_id: str, amount: int) -> tuple[bool, int]:
        """Withdraw credits from bank to wallet. Returns (success, new_wallet_balance)"""
        with self.app.app_context():
            user = User.query.filter_by(id=user_id).first()
            if not user:
                user = User()
                user.id = user_id
                user.credits = 0
                user.bank_credits = 0
                user.has_shield = False
                db.session.add(user)
                db.session.flush()
            
            if user.bank_credits < amount:
                return False, 0
            
            user.bank_credits -= amount
            user.credits += amount
            user.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.debug(f"User {user_id} withdrew {amount} credits from bank")
            return True, user.credits
    
    # Shield system
    def has_shield(self, user_id: str) -> bool:
        """Check if user has shield protection"""
        with self.app.app_context():
            user = User.query.filter_by(id=user_id).first()
            return user.has_shield if user else False
    
    def buy_shield(self, user_id: str) -> bool:
        """Buy shield protection for 500 credits"""
        with self.app.app_context():
            user = User.query.filter_by(id=user_id).first()
            if not user or user.credits < 500:
                return False
            
            user.credits -= 500
            user.has_shield = True
            user.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.debug(f"User {user_id} bought shield protection")
            return True
    
    def remove_shield(self, user_id: str) -> None:
        """Remove shield protection (after successful steal)"""
        with self.app.app_context():
            user = User.query.filter_by(id=user_id).first()
            if user:
                user.has_shield = False
                user.updated_at = datetime.utcnow()
                db.session.commit()
    
    # Robbery and stealing methods
    def rob_wallet(self, robber_id: str, target_id: str) -> tuple[bool, int]:
        """Rob all credits from target's wallet. Returns (success, amount_robbed)"""
        with self.app.app_context():
            target = User.query.filter_by(id=target_id).first()
            if not target or target.credits < 500:
                return False, 0
            
            amount_robbed = target.credits
            target.credits = 0
            
            # Give robbed credits to robber
            robber = User.query.filter_by(id=robber_id).first()
            if not robber:
                robber = User()
                robber.id = robber_id
                robber.credits = 0
                robber.bank_credits = 0
                robber.has_shield = False
                db.session.add(robber)
                db.session.flush()
            
            robber.credits += amount_robbed
            robber.updated_at = datetime.utcnow()
            target.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"User {robber_id} robbed {amount_robbed} credits from {target_id}")
            return True, amount_robbed
    
    def steal_from_bank(self, thief_id: str, target_id: str) -> tuple[bool, int]:
        """Attempt to steal 50% of credits from target's bank. Returns (success, amount_stolen)"""
        with self.app.app_context():
            target = User.query.filter_by(id=target_id).first()
            if not target or target.bank_credits == 0:
                return False, 0
            
            # Check if target has shield protection
            if target.has_shield:
                # Remove shield but prevent steal
                target.has_shield = False
                target.updated_at = datetime.utcnow()
                db.session.commit()
                return False, 0
            
            amount_stolen = target.bank_credits // 2  # 50% of bank credits
            target.bank_credits -= amount_stolen
            
            # Give stolen credits to thief
            thief = User.query.filter_by(id=thief_id).first()
            if not thief:
                thief = User()
                thief.id = thief_id
                thief.credits = 0
                thief.bank_credits = 0
                thief.has_shield = False
                db.session.add(thief)
                db.session.flush()
            
            thief.credits += amount_stolen
            thief.updated_at = datetime.utcnow()
            target.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"User {thief_id} stole {amount_stolen} credits from {target_id}'s bank")
            return True, amount_stolen
    
    def give_credits(self, giver_id: str, receiver_id: str, amount: int) -> tuple[bool, str]:
        """Give credits from one user to another. Returns (success, message)"""
        with self.app.app_context():
            # Get giver
            giver = User.query.filter_by(id=giver_id).first()
            if not giver:
                giver = User()
                giver.id = giver_id
                giver.credits = 0
                giver.bank_credits = 0
                giver.has_shield = False
                db.session.add(giver)
                db.session.flush()
            
            if giver.credits < amount:
                return False, f"Insufficient wallet credits. You have {giver.credits} credits."
            
            # Get receiver
            receiver = User.query.filter_by(id=receiver_id).first()
            if not receiver:
                receiver = User()
                receiver.id = receiver_id
                receiver.credits = 0
                receiver.bank_credits = 0
                receiver.has_shield = False
                db.session.add(receiver)
                db.session.flush()
            
            # Transfer credits
            giver.credits -= amount
            receiver.credits += amount
            giver.updated_at = datetime.utcnow()
            receiver.updated_at = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"User {giver_id} gave {amount} credits to {receiver_id}")
            return True, f"Successfully gave {amount} credits!"
    
    def save_all_data(self) -> bool:
        """Save all data (for compatibility with existing code)"""
        # Database operations are automatically committed, so this is just for logging
        logger.info("Database operations are automatically saved")
        return True
"""
Database models for Discord bot
Uses SQLAlchemy for PostgreSQL integration
"""

import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from datetime import datetime


class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)

# Flask app for database initialization
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "discord-bot-secret")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

db.init_app(app)


class User(db.Model):
    """User model for storing Discord user data"""
    __tablename__ = 'users'
    
    id = db.Column(db.String(50), primary_key=True)  # Discord user ID
    credits = db.Column(db.Integer, default=0)  # Wallet credits (can be robbed)
    bank_credits = db.Column(db.Integer, default=0)  # Bank credits (safer storage)
    has_shield = db.Column(db.Boolean, default=False)  # Shield protection
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<User {self.id}: {self.credits} wallet, {self.bank_credits} bank>'


class UserTimestamp(db.Model):
    """Timestamp model for tracking cooldowns"""
    __tablename__ = 'user_timestamps'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('users.id'), nullable=False)
    timestamp_type = db.Column(db.String(20), nullable=False)  # 'daily', 'work', etc.
    timestamp = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Ensure unique combination of user_id and timestamp_type
    __table_args__ = (db.UniqueConstraint('user_id', 'timestamp_type'),)
    
    def __repr__(self):
        return f'<UserTimestamp {self.user_id} {self.timestamp_type}: {self.timestamp}>'


def init_database():
    """Initialize database tables"""
    with app.app_context():
        db.create_all()
        print("Database tables created successfully!")


if __name__ == "__main__":
    init_database()
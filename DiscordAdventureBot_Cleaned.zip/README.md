# Discord Adventure Bot

A Python-based Discord bot for interactive adventures and waifu features.

## Getting Started

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the bot:
   ```
   python main.py
   ```

Make sure you set your Discord token in a `.env` file or directly in `config.py`.

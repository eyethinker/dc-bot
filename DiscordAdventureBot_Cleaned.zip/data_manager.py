"""
Data persistence manager for Discord bot
Handles credits, timestamps, and all persistent data using JSON files
"""

import json
import os
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional

logger = logging.getLogger(__name__)

class DataManager:
    """Manages persistent data storage for the Discord bot"""
    
    def __init__(self):
        self.data_dir = "data"
        self.credits_file = os.path.join(self.data_dir, "credits.json")
        self.timestamps_file = os.path.join(self.data_dir, "timestamps.json")
        self.bank_file = os.path.join(self.data_dir, "bank.json")
        self.shields_file = os.path.join(self.data_dir, "shields.json")
        self.pets_file = os.path.join(self.data_dir, "pets.json")
        self.marriages_file = os.path.join(self.data_dir, "marriages.json")
        self.gangs_file = os.path.join(self.data_dir, "gangs.json")
        self.user_gangs_file = os.path.join(self.data_dir, "user_gangs.json")
        self.waifus_file = os.path.join(self.data_dir, "waifus.json")
        self.waifu_timestamps_file = os.path.join(self.data_dir, "waifu_timestamps.json")
        
        # Ensure data directory exists
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Load existing data
        self.credits_data = self._load_json(self.credits_file, {})
        self.timestamps_data = self._load_json(self.timestamps_file, {})
        self.bank_data = self._load_json(self.bank_file, {})
        self.shields_data = self._load_json(self.shields_file, {})
        self.pets_data = self._load_json(self.pets_file, {})
        self.marriages_data = self._load_json(self.marriages_file, {})
        self.gangs_data = self._load_json(self.gangs_file, {})
        self.user_gangs_data = self._load_json(self.user_gangs_file, {})
        self.waifus_data = self._load_json(self.waifus_file, {})
        self.waifu_timestamps_data = self._load_json(self.waifu_timestamps_file, {})
        
        logger.info(f"DataManager initialized with {len(self.credits_data)} users")
    
    def _load_json(self, filepath: str, default: dict) -> dict:
        """Load JSON data from file with error handling"""
        try:
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    logger.info(f"Loaded data from {filepath}")
                    return data
            else:
                logger.info(f"File {filepath} doesn't exist, using default data")
                return default.copy()
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error loading {filepath}: {e}")
            # Backup corrupted file
            if os.path.exists(filepath):
                backup_name = f"{filepath}.backup"
                os.rename(filepath, backup_name)
                logger.warning(f"Corrupted file backed up as {backup_name}")
            return default.copy()
    
    def _save_json(self, filepath: str, data: dict) -> bool:
        """Save JSON data to file with error handling"""
        try:
            # Write to temporary file first
            temp_file = f"{filepath}.tmp"
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False, default=str)
            
            # Replace original file with temporary file
            if os.path.exists(filepath):
                os.remove(filepath)
            os.rename(temp_file, filepath)
            
            logger.debug(f"Saved data to {filepath}")
            return True
        except (IOError, OSError) as e:
            logger.error(f"Error saving {filepath}: {e}")
            # Clean up temporary file if it exists
            if os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except:
                    pass
            return False
    
    def save_all_data(self) -> bool:
        """Save all data to files"""
        credits_saved = self._save_json(self.credits_file, self.credits_data)
        timestamps_saved = self._save_json(self.timestamps_file, self.timestamps_data)
        bank_saved = self._save_json(self.bank_file, self.bank_data)
        shields_saved = self._save_json(self.shields_file, self.shields_data)
        pets_saved = self._save_json(self.pets_file, self.pets_data)
        marriages_saved = self._save_json(self.marriages_file, self.marriages_data)
        gangs_saved = self._save_json(self.gangs_file, self.gangs_data)
        user_gangs_saved = self._save_json(self.user_gangs_file, self.user_gangs_data)
        waifus_saved = self._save_json(self.waifus_file, self.waifus_data)
        waifu_timestamps_saved = self._save_json(self.waifu_timestamps_file, self.waifu_timestamps_data)
        
        success = credits_saved and timestamps_saved and bank_saved and shields_saved and pets_saved and marriages_saved and gangs_saved and user_gangs_saved and waifus_saved and waifu_timestamps_saved
        if success:
            logger.info("All data saved successfully")
        else:
            logger.warning("Some data failed to save")
        
        return success
    
    # Credits management
    def get_credits(self, user_id: str) -> int:
        """Get user's credit balance"""
        return self.credits_data.get(user_id, 0)
    
    def set_credits(self, user_id: str, amount: int) -> None:
        """Set user's credit balance"""
        self.credits_data[user_id] = max(0, amount)
        logger.debug(f"Set credits for {user_id}: {amount}")
    
    def add_credits(self, user_id: str, amount: int) -> int:
        """Add credits to user's balance (can be negative)"""
        current = self.get_credits(user_id)
        new_amount = max(0, current + amount)
        self.credits_data[user_id] = new_amount
        logger.debug(f"Added {amount} credits to {user_id}: {current} -> {new_amount}")
        return new_amount
    
    def get_all_credits(self) -> Dict[str, int]:
        """Get all users' credit data"""
        return self.credits_data.copy()
    
    # Timestamp management
    def _get_timestamp(self, user_id: str, timestamp_type: str) -> Optional[datetime]:
        """Get timestamp for user and type"""
        user_timestamps = self.timestamps_data.get(user_id, {})
        timestamp_str = user_timestamps.get(timestamp_type)
        
        if timestamp_str:
            try:
                return datetime.fromisoformat(timestamp_str)
            except ValueError:
                logger.warning(f"Invalid timestamp format for {user_id}.{timestamp_type}: {timestamp_str}")
                return None
        return None
    
    def _set_timestamp(self, user_id: str, timestamp_type: str, timestamp: datetime) -> None:
        """Set timestamp for user and type"""
        if user_id not in self.timestamps_data:
            self.timestamps_data[user_id] = {}
        
        self.timestamps_data[user_id][timestamp_type] = timestamp.isoformat()
        logger.debug(f"Set {timestamp_type} timestamp for {user_id}: {timestamp}")
    
    def get_daily_timestamp(self, user_id: str) -> Optional[datetime]:
        """Get user's last daily claim timestamp"""
        return self._get_timestamp(user_id, "daily")
    
    def set_daily_timestamp(self, user_id: str, timestamp: datetime) -> None:
        """Set user's daily claim timestamp"""
        self._set_timestamp(user_id, "daily", timestamp)
    
    def get_work_timestamp(self, user_id: str) -> Optional[datetime]:
        """Get user's last work timestamp"""
        return self._get_timestamp(user_id, "work")
    
    def set_work_timestamp(self, user_id: str, timestamp: datetime) -> None:
        """Set user's work timestamp"""
        self._set_timestamp(user_id, "work", timestamp)
    
    # User management
    def get_user_stats(self, user_id: str) -> Dict:
        """Get comprehensive user statistics"""
        return {
            "credits": self.get_credits(user_id),
            "last_daily": self.get_daily_timestamp(user_id),
            "last_work": self.get_work_timestamp(user_id)
        }
    
    def delete_user_data(self, user_id: str) -> bool:
        """Delete all data for a user"""
        deleted_something = False
        
        if user_id in self.credits_data:
            del self.credits_data[user_id]
            deleted_something = True
        
        if user_id in self.timestamps_data:
            del self.timestamps_data[user_id]
            deleted_something = True
        
        if deleted_something:
            logger.info(f"Deleted all data for user {user_id}")
            self.save_all_data()
        
        return deleted_something
    
    def get_total_users(self) -> int:
        """Get total number of users with data"""
        all_users = set(self.credits_data.keys()) | set(self.timestamps_data.keys())
        return len(all_users)
    
    def get_total_credits_in_economy(self) -> int:
        """Get total credits across all users"""
        wallet_total = sum(self.credits_data.values())
        bank_total = sum(self.bank_data.values())
        return wallet_total + bank_total
    
    # Banking system methods
    def get_bank_credits(self, user_id: str) -> int:
        """Get user's bank credit balance"""
        return self.bank_data.get(user_id, 0)
    
    def deposit_to_bank(self, user_id: str, amount: int = None) -> tuple[int, int]:
        """Deposit credits from wallet to bank. Returns (deposited_amount, new_bank_balance)"""
        wallet_credits = self.get_credits(user_id)
        
        if amount is None:  # Deposit all
            amount = wallet_credits
        else:
            amount = min(amount, wallet_credits)
        
        self.add_credits(user_id, -amount)  # Remove from wallet
        self.bank_data[user_id] = self.bank_data.get(user_id, 0) + amount
        
        logger.debug(f"User {user_id} deposited {amount} credits to bank")
        return amount, self.bank_data[user_id]
    
    def withdraw_from_bank(self, user_id: str, amount: int) -> tuple[bool, int]:
        """Withdraw credits from bank to wallet. Returns (success, new_wallet_balance)"""
        bank_balance = self.get_bank_credits(user_id)
        
        if bank_balance < amount:
            return False, 0
        
        self.bank_data[user_id] = bank_balance - amount
        new_wallet_balance = self.add_credits(user_id, amount)
        
        logger.debug(f"User {user_id} withdrew {amount} credits from bank")
        return True, new_wallet_balance
    
    # Shield system
    def has_shield(self, user_id: str) -> bool:
        """Check if user has active shield protection"""
        shield_data = self.shields_data.get(user_id, {})
        if not shield_data or not isinstance(shield_data, dict):
            return False
        
        if not shield_data.get("active", False):
            return False
        
        # Check if shield has expired (5 hours = 18000 seconds)
        shield_time = shield_data.get("expires_at")
        if shield_time:
            try:
                expire_time = datetime.fromisoformat(shield_time)
                if datetime.utcnow() > expire_time:
                    # Shield expired, remove it
                    self.shields_data[user_id] = {"active": False}
                    return False
            except ValueError:
                return False
        
        return True
    
    def buy_shield(self, user_id: str) -> bool:
        """Buy shield protection for 500 credits (lasts 5 hours)"""
        if self.get_credits(user_id) < 500:
            return False
        
        self.add_credits(user_id, -500)
        
        # Set shield to expire in 5 hours
        expire_time = datetime.utcnow() + timedelta(hours=5)
        self.shields_data[user_id] = {
            "active": True,
            "expires_at": expire_time.isoformat()
        }
        
        logger.debug(f"User {user_id} bought shield protection until {expire_time}")
        return True
    
    def get_shield_time_left(self, user_id: str) -> int:
        """Get shield time left in seconds"""
        shield_data = self.shields_data.get(user_id, {})
        if not shield_data or not isinstance(shield_data, dict):
            return 0
        
        if not shield_data.get("active", False):
            return 0
        
        shield_time = shield_data.get("expires_at")
        if shield_time:
            try:
                expire_time = datetime.fromisoformat(shield_time)
                time_left = (expire_time - datetime.utcnow()).total_seconds()
                return max(0, int(time_left))
            except ValueError:
                return 0
        
        return 0
    
    def remove_shield(self, user_id: str) -> None:
        """Remove shield protection (deprecated - shields are now unbreakable)"""
        # This method is now deprecated since shields are unbreakable
        pass
    
    # Robbery and stealing methods
    def rob_wallet(self, robber_id: str, target_id: str) -> tuple[bool, int]:
        """Rob all credits from target's wallet. Returns (success, amount_robbed)"""
        target_wallet = self.get_credits(target_id)
        
        if target_wallet < 500:
            return False, 0
        
        # Transfer all wallet credits from target to robber
        self.set_credits(target_id, 0)
        self.add_credits(robber_id, target_wallet)
        
        logger.info(f"User {robber_id} robbed {target_wallet} credits from {target_id}")
        return True, target_wallet
    
    def steal_from_bank(self, thief_id: str, target_id: str) -> tuple[bool, int]:
        """Attempt to steal 50% of credits from target's bank. Returns (success, amount_stolen)"""
        target_bank = self.get_bank_credits(target_id)
        
        if target_bank == 0:
            return False, 0
        
        # Check if target has active shield protection (shields are now unbreakable)
        if self.has_shield(target_id):
            return False, 0
        
        amount_stolen = target_bank // 2  # 50% of bank credits
        self.bank_data[target_id] = target_bank - amount_stolen
        self.add_credits(thief_id, amount_stolen)
        
        logger.info(f"User {thief_id} stole {amount_stolen} credits from {target_id}'s bank")
        return True, amount_stolen
    
    def give_credits(self, giver_id: str, receiver_id: str, amount: int) -> tuple[bool, str]:
        """Give credits from one user to another. Returns (success, message)"""
        giver_wallet = self.get_credits(giver_id)
        
        if giver_wallet < amount:
            return False, f"Insufficient wallet credits. You have {giver_wallet} credits."
        
        # Transfer credits
        self.add_credits(giver_id, -amount)
        self.add_credits(receiver_id, amount)
        
        logger.info(f"User {giver_id} gave {amount} credits to {receiver_id}")
        return True, f"Successfully gave {amount} credits!"
    
    # Pet system methods
    def get_user_pet(self, user_id: str) -> dict:
        """Get user's pet data"""
        return self.pets_data.get(user_id, {})
    
    def buy_pet(self, user_id: str, pet_type: str, pet_name: str, cost: int) -> bool:
        """Buy a pet for the user"""
        if self.get_credits(user_id) < cost:
            return False
        
        pet_stats = {
            "ant": {"hp": 10, "max_hp": 10, "attack": 2},
            "cat": {"hp": 25, "max_hp": 25, "attack": 5},
            "panda": {"hp": 40, "max_hp": 40, "attack": 8},
            "tiger": {"hp": 60, "max_hp": 60, "attack": 12},
            "butterfly": {"hp": 15, "max_hp": 15, "attack": 3}
        }
        
        self.add_credits(user_id, -cost)
        self.pets_data[user_id] = {
            "type": pet_type,
            "name": pet_name,
            "hp": pet_stats[pet_type]["hp"],
            "max_hp": pet_stats[pet_type]["max_hp"],
            "attack": pet_stats[pet_type]["attack"],
            "alive": True
        }
        
        logger.info(f"User {user_id} bought a {pet_type} named {pet_name}")
        return True
    
    def attack_pet(self, attacker_id: str, target_id: str) -> tuple[bool, str]:
        """Attack another user's pet"""
        attacker_pet = self.get_user_pet(attacker_id)
        target_pet = self.get_user_pet(target_id)
        
        if not attacker_pet or not attacker_pet.get("alive", False):
            return False, "You don't have a living pet to attack with!"
        
        if not target_pet or not target_pet.get("alive", False):
            return False, "Target doesn't have a living pet to attack!"
        
        damage = attacker_pet["attack"]
        target_pet["hp"] = max(0, target_pet["hp"] - damage)
        
        if target_pet["hp"] == 0:
            target_pet["alive"] = False
            result = f"{attacker_pet['name']} dealt {damage} damage to {target_pet['name']} and killed it!"
        else:
            result = f"{attacker_pet['name']} dealt {damage} damage to {target_pet['name']}! ({target_pet['hp']}/{target_pet['max_hp']} HP left)"
        
        self.pets_data[target_id] = target_pet
        logger.info(f"Pet {attacker_pet['name']} attacked {target_pet['name']} for {damage} damage")
        return True, result
    
    def revive_pet(self, user_id: str, cost: int) -> bool:
        """Revive user's dead pet"""
        if self.get_credits(user_id) < cost:
            return False
        
        pet = self.get_user_pet(user_id)
        if not pet or pet.get("alive", False):
            return False
        
        self.add_credits(user_id, -cost)
        pet["hp"] = pet["max_hp"]
        pet["alive"] = True
        self.pets_data[user_id] = pet
        
        logger.info(f"User {user_id} revived their pet {pet['name']}")
        return True
    
    def nickname_pet(self, user_id: str, new_name: str) -> bool:
        """Change pet's nickname"""
        pet = self.get_user_pet(user_id)
        if not pet:
            return False
        
        pet["name"] = new_name
        self.pets_data[user_id] = pet
        logger.info(f"User {user_id} nicknamed their pet {new_name}")
        return True
    
    # Marriage system
    def is_married(self, user_id: str) -> str:
        """Check if user is married, returns partner ID or empty string"""
        return self.marriages_data.get(user_id, "")
    
    def marry_users(self, user1_id: str, user2_id: str) -> bool:
        """Marry two users"""
        if self.is_married(user1_id) or self.is_married(user2_id):
            return False
        
        self.marriages_data[user1_id] = user2_id
        self.marriages_data[user2_id] = user1_id
        logger.info(f"Users {user1_id} and {user2_id} got married")
        return True

    def divorce_users(self, user1_id: str, user2_id: str) -> bool:
        """Divorce two users"""
        try:
            # Remove marriage status from both users
            if user1_id in self.marriages_data:
                del self.marriages_data[user1_id]
            if user2_id in self.marriages_data:
                del self.marriages_data[user2_id]
            
            logger.info(f"Users {user1_id} and {user2_id} got divorced")
            return True
        except Exception as e:
            logger.error(f"Error divorcing users {user1_id} and {user2_id}: {e}")
            return False
    
    # Gang system methods
    def gang_exists(self, gang_name: str) -> bool:
        """Check if gang name already exists"""
        return gang_name.lower() in [gang["name"].lower() for gang in self.gangs_data.values()]
    
    def create_gang(self, owner_id: str, gang_name: str) -> bool:
        """Create a new gang"""
        if self.get_credits(owner_id) < 10000:
            return False
        
        if self.gang_exists(gang_name):
            return False
        
        # Deduct credits
        self.add_credits(owner_id, -10000)
        
        # Create gang
        gang_id = f"gang_{len(self.gangs_data) + 1}"
        self.gangs_data[gang_id] = {
            "name": gang_name,
            "owner_id": owner_id,
            "created_at": datetime.utcnow().isoformat(),
            "logo_url": "",
            "bank": 0,
            "members": {
                owner_id: {
                    "role": "owner",
                    "joined_at": datetime.utcnow().isoformat(),
                    "contributed": 0
                }
            }
        }
        
        # Add user to gang
        self.user_gangs_data[owner_id] = {
            "gang_id": gang_id,
            "gang_name": gang_name,
            "role": "owner"
        }
        
        logger.info(f"User {owner_id} created gang {gang_name}")
        return True
    
    def get_user_gang(self, user_id: str) -> dict:
        """Get user's gang information"""
        return self.user_gangs_data.get(user_id, {})
    
    def join_gang(self, user_id: str, gang_name: str) -> bool:
        """Join a gang"""
        # Find gang by name
        gang_id = None
        for gid, gang_data in self.gangs_data.items():
            if gang_data["name"] == gang_name:
                gang_id = gid
                break
        
        if not gang_id:
            return False
        
        # Add user to gang
        self.gangs_data[gang_id]["members"][user_id] = {
            "role": "member",
            "joined_at": datetime.utcnow().isoformat(),
            "contributed": 0
        }
        
        self.user_gangs_data[user_id] = {
            "gang_id": gang_id,
            "gang_name": gang_name,
            "role": "member"
        }
        
        logger.info(f"User {user_id} joined gang {gang_name}")
        return True
    
    def get_gang_info(self, user_id: str) -> dict:
        """Get detailed gang information for a user"""
        user_gang = self.get_user_gang(user_id)
        if not user_gang:
            return {}
        
        gang_id = user_gang["gang_id"]
        gang_data = self.gangs_data.get(gang_id, {})
        
        if not gang_data:
            return {}
        
        return {
            "gang_name": gang_data["name"],
            "members": gang_data["members"],
            "total_bank": gang_data["bank"],
            "logo_url": gang_data.get("logo_url", ""),
            "owner_id": gang_data["owner_id"]
        }
    
    def deposit_to_gang(self, user_id: str, amount: int) -> tuple[bool, int]:
        """Deposit credits to gang bank"""
        user_gang = self.get_user_gang(user_id)
        if not user_gang:
            return False, 0
        
        if self.get_credits(user_id) < amount:
            return False, 0
        
        gang_id = user_gang["gang_id"]
        
        # Deduct from user wallet
        self.add_credits(user_id, -amount)
        
        # Add to gang bank
        self.gangs_data[gang_id]["bank"] += amount
        
        # Update user's contribution
        self.gangs_data[gang_id]["members"][user_id]["contributed"] += amount
        
        new_contribution = self.gangs_data[gang_id]["members"][user_id]["contributed"]
        
        logger.info(f"User {user_id} deposited {amount} to gang {gang_id}")
        return True, new_contribution
    
    def withdraw_from_gang(self, user_id: str, amount: int) -> tuple[bool, int]:
        """Withdraw credits from gang bank (owner only)"""
        user_gang = self.get_user_gang(user_id)
        if not user_gang or user_gang["role"] != "owner":
            return False, 0
        
        gang_id = user_gang["gang_id"]
        gang_bank = self.gangs_data[gang_id]["bank"]
        
        if gang_bank < amount:
            return False, 0
        
        # Remove from gang bank
        self.gangs_data[gang_id]["bank"] -= amount
        
        # Add to user wallet
        new_balance = self.add_credits(user_id, amount)
        
        logger.info(f"User {user_id} withdrew {amount} from gang {gang_id}")
        return True, new_balance
    
    def get_gang_leaderboard(self) -> list:
        """Get gang leaderboard sorted by total bank"""
        leaderboard = []
        
        for gang_id, gang_data in self.gangs_data.items():
            leaderboard.append({
                "gang_name": gang_data["name"],
                "total_bank": gang_data["bank"],
                "member_count": len(gang_data["members"]),
                "owner_id": gang_data["owner_id"],
                "logo_url": gang_data.get("logo_url", "")
            })
        
        return sorted(leaderboard, key=lambda x: x["total_bank"], reverse=True)
    
    def set_gang_logo(self, user_id: str, logo_url: str) -> bool:
        """Set gang logo (owner only)"""
        user_gang = self.get_user_gang(user_id)
        if not user_gang or user_gang["role"] != "owner":
            return False
        
        gang_id = user_gang["gang_id"]
        self.gangs_data[gang_id]["logo_url"] = logo_url
        
        logger.info(f"User {user_id} set logo for gang {gang_id}")
        return True
    
    def leave_gang(self, user_id: str) -> bool:
        """Leave a gang (non-owners only)"""
        user_gang = self.get_user_gang(user_id)
        if not user_gang:
            return False
        
        if user_gang["role"] == "owner":
            return False  # Owners cannot leave
        
        gang_id = user_gang["gang_id"]
        
        # Remove user from gang members
        if user_id in self.gangs_data[gang_id]["members"]:
            del self.gangs_data[gang_id]["members"][user_id]
        
        # Remove user from user_gangs
        if user_id in self.user_gangs_data:
            del self.user_gangs_data[user_id]
        
        logger.info(f"User {user_id} left gang {gang_id}")
        return True
    
    # Waifu/Husbando Collection System
    def get_user_waifus(self, user_id: str) -> dict:
        """Get user's waifu collection"""
        return self.waifus_data.get(user_id, {})
    
    def add_waifu_to_collection(self, user_id: str, waifu_id: str, waifu_data: dict) -> bool:
        """Add a waifu to user's collection"""
        if user_id not in self.waifus_data:
            self.waifus_data[user_id] = {}
        
        # Add timestamp when acquired
        waifu_data["acquired_at"] = datetime.utcnow().isoformat()
        self.waifus_data[user_id][waifu_id] = waifu_data
        
        logger.info(f"User {user_id} acquired waifu {waifu_id}")
        return True
    
    def remove_waifu_from_collection(self, user_id: str, waifu_id: str) -> bool:
        """Remove a waifu from user's collection"""
        if user_id not in self.waifus_data or waifu_id not in self.waifus_data[user_id]:
            return False
        
        del self.waifus_data[user_id][waifu_id]
        logger.info(f"User {user_id} released waifu {waifu_id}")
        return True
    
    def get_waifu_battle_timestamp(self, user_id: str) -> Optional[datetime]:
        """Get user's last waifu battle timestamp"""
        return self._get_timestamp_from_file(user_id, "waifu_battle", self.waifu_timestamps_data)
    
    def set_waifu_battle_timestamp(self, user_id: str, timestamp: datetime) -> None:
        """Set user's waifu battle timestamp"""
        self._set_timestamp_to_file(user_id, "waifu_battle", timestamp, self.waifu_timestamps_data)
    
    def _get_timestamp_from_file(self, user_id: str, timestamp_type: str, data_dict: dict) -> Optional[datetime]:
        """Get timestamp from specific data file"""
        user_timestamps = data_dict.get(user_id, {})
        timestamp_str = user_timestamps.get(timestamp_type)
        
        if timestamp_str:
            try:
                return datetime.fromisoformat(timestamp_str)
            except ValueError:
                logger.warning(f"Invalid timestamp format for {user_id}.{timestamp_type}: {timestamp_str}")
                return None
        return None
    
    def _set_timestamp_to_file(self, user_id: str, timestamp_type: str, timestamp: datetime, data_dict: dict) -> None:
        """Set timestamp to specific data file"""
        if user_id not in data_dict:
            data_dict[user_id] = {}
        
        data_dict[user_id][timestamp_type] = timestamp.isoformat()
        logger.debug(f"Set {timestamp_type} timestamp for {user_id}: {timestamp}")
    
    def get_user_completed_series(self, user_id: str) -> list:
        """Get list of completed anime series for user"""
        from waifu_data import ANIME_SERIES
        
        user_waifus = self.get_user_waifus(user_id)
        user_waifu_ids = set(user_waifus.keys())
        completed_series = []
        
        for series_name, required_waifus in ANIME_SERIES.items():
            if set(required_waifus).issubset(user_waifu_ids):
                completed_series.append(series_name)
        
        return completed_series
    
    def get_passive_income_bonus(self, user_id: str) -> int:
        """Calculate passive income bonus from waifu collection"""
        from waifu_data import RARITY_CONFIG
        
        user_waifus = self.get_user_waifus(user_id)
        total_bonus = 0
        
        # Bonus from individual waifus
        for waifu_data in user_waifus.values():
            rarity = waifu_data.get("rarity", "common")
            total_bonus += RARITY_CONFIG.get(rarity, {}).get("passive_bonus", 0)
        
        # Bonus from completed series (3% per completed series)
        completed_series = self.get_user_completed_series(user_id)
        total_bonus += len(completed_series) * 3
        
        return total_bonus
    
    def get_strongest_waifu(self, user_id: str) -> tuple:
        """Get user's strongest waifu for battles. Returns (waifu_id, waifu_data) or (None, None)"""
        user_waifus = self.get_user_waifus(user_id)
        
        if not user_waifus:
            return None, None
        
        strongest_id = None
        strongest_data = None
        max_power = 0
        
        for waifu_id, waifu_data in user_waifus.items():
            power = waifu_data.get("power", 0)
            if power > max_power:
                max_power = power
                strongest_id = waifu_id
                strongest_data = waifu_data
        
        return strongest_id, strongest_data

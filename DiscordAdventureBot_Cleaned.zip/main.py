"""
Main entry point for the Discord bot on Replit
Handles bot initialization, keep-alive server, and continuous operation
"""

import os
import asyncio
import logging
from threading import Thread
from keep_alive import keep_alive
from bot import bot
from config import BOT_TOKEN

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

def run_bot():
    """Run the Discord bot with error handling and auto-restart"""
    while True:
        try:
            logger.info("Starting Discord bot...")
            bot.run(BOT_TOKEN)
        except Exception as e:
            logger.error(f"Bot crashed with error: {e}")
            logger.info("Restarting bot in 5 seconds...")
            asyncio.sleep(5)

def main():
    """Main function to start both keep-alive server and Discord bot"""
    logger.info("Initializing Replit Discord Bot...")
    
    # Ensure data directory exists
    os.makedirs('data', exist_ok=True)
    
    # Start the keep-alive web server in a separate thread
    logger.info("Starting keep-alive server...")
    keep_alive_thread = Thread(target=keep_alive)
    keep_alive_thread.daemon = True
    keep_alive_thread.start()
    
    # Start the Discord bot
    run_bot()

if __name__ == "__main__":
    main()

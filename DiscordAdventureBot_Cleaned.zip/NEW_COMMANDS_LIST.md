# 🎉 New Twinkii Bot Commands - Complete List

## ✅ Fixed Commands
- **`.leaderboard`** - Fixed to show top 10 users by total credits (wallet + bank)

## 🆕 New Gambling Commands
- **`.flip <amount>`** - Flip a coin, 50/50 chance to double your bet or lose it all
- **`.bj <amount>`** - Play blackjack against the dealer to win or lose credits

## 🛒 Shop System
- **`.shop`** - Browse the complete shop with shields and pets
- **`.shield`** - Buy shield protection for 500 credits (existing command)

## 🐾 Pet System
- **`.buypet <type> <name>`** - Buy a pet from the shop
  - Available pets: ant (100c), cat (300c), panda (600c), tiger (1000c), butterfly (200c)
  - Each pet has different HP and attack stats
- **`.attack @user`** - Attack another user's pet with your pet
- **`.revive`** - Revive your dead pet with a potion (150 credits)
- **`.nickname <new_name>`** - Change your pet's nickname

### Pet Stats:
- 🐜 **Ant**: HP 10, Attack 2 (100 credits)
- 🐱 **Cat**: HP 25, Attack 5 (300 credits)
- 🦋 **Butterfly**: HP 15, Attack 3 (200 credits)
- 🐼 **Panda**: HP 40, Attack 8 (600 credits)
- 🐅 **Tiger**: HP 60, Attack 12 (1000 credits)

## 💕 Social & Marriage Commands
- **`.spit @user`** - Spit on someone (playful interaction)
- **`.love @user`** - Show love to someone
- **`.lick @user`** - Lick someone (silly interaction)
- **`.marry @user`** - Propose marriage (target responds with .yes/.no)
- **`.yes`** - Accept a marriage proposal
- **`.no`** - Decline a marriage proposal
- **`.divorce @user`** - Divorce your spouse (both can remarry later)

## 👤 Profile System
- **`.profile [@user]`** - Show comprehensive user profile including:
  - Credits (wallet, bank, total)
  - Server rank
  - Shield status
  - Pet information (name, HP, attack, status)
  - Marriage status
  - Bot progress

## 🎮 Enhanced Features
- **Marriage tracking** - Profile shows if user is married
- **Pet battle system** - Pets can attack each other and lose HP
- **Death/revival system** - Dead pets can be revived with potions
- **Comprehensive ranking** - Based on total credits across wallet and bank
- **Enhanced balance display** - Shows wallet, bank, total, and shield status

## 📊 Command Categories Summary
1. **Economy**: daily, work, bal, dep, take, give, leaderboard
2. **Gambling**: bet, slots, flip, bj, rps
3. **Social**: hug, kiss, marry, kick, slap, kill, chapal, curse, spit, love, lick
4. **Combat**: rob, steal, shield, attack (pets)
5. **Shop**: shop, buypet, revive, shield
6. **Pets**: buypet, attack, revive, nickname
7. **Profile**: profile, bal
8. **Games**: gtf, flag, skip, drop, pick
9. **Utility**: ping, help

## 🎯 Total New Commands Added: 9
1. `.flip` - Coin flip gambling
2. `.shop` - Shop browsing
3. `.buypet` - Pet purchasing
4. `.attack` - Pet battles
5. `.revive` - Pet revival
6. `.nickname` - Pet renaming
7. `.spit` - Social interaction
8. `.love` - Social interaction
9. `.lick` - Social interaction
10. `.bj` - Blackjack gambling
11. `.profile` - User profiles

Plus 1 fixed command (`.leaderboard`) and enhanced existing features!
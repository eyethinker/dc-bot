# Discord Bot - Twinkii Bot

## Overview

This is a comprehensive Discord bot called "Twinkii Bot" built with Python and discord.py. The bot features an economy system, social interactions, gaming mechanics, and pet management. It's designed to run on Replit with a keep-alive web server and uses both JSON file storage and PostgreSQL database options for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: discord.py with Python
- **Command System**: Prefix-based commands using `.` as the default prefix
- **Data Persistence**: Dual storage approach with JSON files and PostgreSQL database
- **Web Server**: Flask-based keep-alive server for Replit hosting
- **Async Processing**: Asynchronous command handling and background tasks

### Core Components
- **Bot Core** (`bot.py`): Main Discord bot logic with command handlers
- **Data Management** (`data_manager.py`): JSON-based data persistence layer
- **Database Management** (`database_manager.py`): PostgreSQL operations with SQLAlchemy
- **Configuration** (`config.py`): Environment variable management
- **Web Server** (`keep_alive.py`): Flask server for hosting on Replit

## Key Components

### Economy System
- **Credits**: Wallet and bank storage system
- **Daily/Work Commands**: Time-gated credit earning
- **Gambling**: Coin flip and blackjack games
- **Shop System**: Purchase shields and pets
- **Robbery Protection**: Shield system for security

### Social Features
- **Marriage System**: Users can propose, marry, and divorce
- **Social Interactions**: Commands like spit, love, lick
- **Profile System**: Comprehensive user profiles with stats
- **Leaderboards**: Ranking by total credits

### Gaming Features
- **Pet System**: Buy, battle, and care for pets with different stats
- **Flag Game**: Country flag guessing game
- **Credit Drops**: Random credit drops for users to claim
- **Lootbox System**: Timed code-based rewards

### Pet Combat System
- **Pet Types**: Ant, Cat, Butterfly, Panda, Tiger with varying HP/Attack
- **Battle Mechanics**: Pet vs pet combat with damage calculation
- **Revival System**: Potion-based pet revival
- **Customization**: Pet naming and nickname changes

## Data Flow

### User Interaction Flow
1. User sends command with `.` prefix
2. Bot validates user permissions and cooldowns
3. Data retrieved from JSON files or database
4. Command logic executed with business rules
5. Results saved to persistent storage
6. Response sent to Discord channel

### Data Storage Strategy
- **JSON Files**: Primary storage for economy, pets, marriages, timestamps
- **PostgreSQL**: Alternative/future storage with SQLAlchemy models
- **Auto-save**: Periodic data persistence every 5 minutes
- **Backup System**: Configurable backup functionality

## External Dependencies

### Core Libraries
- **discord.py**: Discord API integration
- **Flask**: Web server for keep-alive functionality
- **SQLAlchemy**: Database ORM for PostgreSQL
- **aiohttp**: Async HTTP requests for flag images

### Third-party Services
- **Flag CDN**: flagcdn.com for country flag images
- **Replit Hosting**: Cloud hosting with environment variables
- **PostgreSQL**: Database service (optional)

### Environment Variables
- `DISCORD_BOT_TOKEN`: Bot authentication token
- `COMMAND_PREFIX`: Bot command prefix (default: '.')
- `DATABASE_URL`: PostgreSQL connection string
- Various configuration settings for limits and cooldowns

## Deployment Strategy

### Replit Deployment
- **Keep-alive Server**: Flask web server prevents bot sleeping
- **Environment Secrets**: Bot token and sensitive config stored securely
- **Auto-restart**: Error handling with automatic bot restart
- **Health Endpoints**: Status monitoring via HTTP endpoints

### Data Management
- **Local Storage**: JSON files in `/data` directory
- **Database Option**: PostgreSQL for scalable data storage
- **Backup Strategy**: File-based backups with rotation
- **Migration Support**: Dual storage system allows data migration

### Monitoring and Logging
- **Structured Logging**: File and console output with log levels
- **Error Handling**: Comprehensive exception catching and recovery
- **Health Checks**: Web endpoints for service monitoring
- **Performance Tracking**: User activity and command usage logging

### Scalability Considerations
- **Database Ready**: PostgreSQL models prepared for growth
- **Modular Design**: Separated data management for easy scaling
- **Configuration Driven**: Environment-based settings for different deployments
- **Resource Limits**: Configurable limits to prevent abuse
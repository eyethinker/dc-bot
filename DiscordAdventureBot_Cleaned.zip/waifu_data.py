
"""
Waifu/Husbando character database for gacha system
"""

WAIFU_DATABASE = {
    # Common Characters (50% drop rate)
    "sakura_haruno": {
        "name": "Sakura Haruno",
        "anime": "Naruto",
        "rarity": "common",
        "power": 2,
        "image": "https://cdn.myanimelist.net/images/characters/9/69275.jpg",
        "description": "Medical ninja from Konoha"
    },
    "krillin": {
        "name": "Krillin",
        "anime": "Dragon Ball",
        "rarity": "common",
        "power": 3,
        "image": "https://cdn.myanimelist.net/images/characters/7/284129.jpg",
        "description": "Goku's loyal friend and fighter"
    },
    "chopper": {
        "name": "Tony Tony Chopper",
        "anime": "One Piece",
        "rarity": "common",
        "power": 2,
        "image": "https://cdn.myanimelist.net/images/characters/9/310307.jpg",
        "description": "The Straw Hats' doctor"
    },
    "hinata_hyuga": {
        "name": "Hinata Hyuga",
        "anime": "Naruto",
        "rarity": "common",
        "power": 3,
        "image": "https://example.com/your-hinata-image.jpg",
        "description": "Gentle ninja with Byakugan"
    },
    "tanjiro_kamado": {
        "name": "Tanjiro Kamado",
        "anime": "Demon Slayer",
        "rarity": "common",
        "power": 4,
        "image": "https://cdn.myanimelist.net/images/characters/4/377245.jpg",
        "description": "Kind-hearted demon slayer"
    },
    "usopp": {
        "name": "Usopp",
        "anime": "One Piece",
        "rarity": "common",
        "power": 2,
        "image": "https://cdn.myanimelist.net/images/characters/13/310330.jpg",
        "description": "The Straw Hats' sniper"
    },
    "yamcha": {
        "name": "Yamcha",
        "anime": "Dragon Ball",
        "rarity": "common",
        "power": 2,
        "image": "https://cdn.myanimelist.net/images/characters/12/284151.jpg",
        "description": "Desert bandit turned fighter"
    },
    "orihime_inoue": {
        "name": "Orihime Inoue",
        "anime": "Bleach",
        "rarity": "common",
        "power": 3,
        "image": "https://cdn.myanimelist.net/images/characters/4/52037.jpg",
        "description": "Healer with Shun Shun Rikka"
    },

    # Rare Characters (30% drop rate)
    "levi_ackerman": {
        "name": "Levi Ackerman",
        "anime": "Attack on Titan",
        "rarity": "rare",
        "power": 7,
        "image": "https://cdn.myanimelist.net/images/characters/2/241413.jpg",
        "description": "Humanity's strongest soldier"
    },
    "nezuko_kamado": {
        "name": "Nezuko Kamado",
        "anime": "Demon Slayer",
        "rarity": "rare",
        "power": 6,
        "image": "https://cdn.myanimelist.net/images/characters/4/377246.jpg",
        "description": "Demon who protects humans"
    },
    "megumin": {
        "name": "Megumin",
        "anime": "KonoSuba",
        "rarity": "rare",
        "power": 8,
        "image": "https://cdn.myanimelist.net/images/characters/4/322291.jpg",
        "description": "Explosion magic specialist"
    },
    "sasuke_uchiha": {
        "name": "Sasuke Uchiha",
        "anime": "Naruto",
        "rarity": "rare",
        "power": 8,
        "image": "https://cdn.myanimelist.net/images/characters/9/131317.jpg",
        "description": "Last Uchiha with Sharingan"
    },
    "ichigo_kurosaki": {
        "name": "Ichigo Kurosaki",
        "anime": "Bleach",
        "rarity": "rare",
        "power": 7,
        "image": "https://cdn.myanimelist.net/images/characters/3/89696.jpg",
        "description": "Soul Reaper substitute"
    },
    "roronoa_zoro": {
        "name": "Roronoa Zoro",
        "anime": "One Piece",
        "rarity": "rare",
        "power": 8,
        "image": "https://cdn.myanimelist.net/images/characters/3/100534.jpg",
        "description": "Three-sword style swordsman"
    },
    "vegeta": {
        "name": "Vegeta",
        "anime": "Dragon Ball",
        "rarity": "rare",
        "power": 9,
        "image": "https://cdn.myanimelist.net/images/characters/4/284127.jpg",
        "description": "Prince of all Saiyans"
    },
    "mikasa_ackerman": {
        "name": "Mikasa Ackerman",
        "anime": "Attack on Titan",
        "rarity": "rare",
        "power": 7,
        "image": "https://cdn.myanimelist.net/images/characters/9/215563.jpg",
        "description": "Elite Survey Corps member"
    },

    # Epic Characters (15% drop rate)
    "killua_zoldyck": {
        "name": "Killua Zoldyck",
        "anime": "Hunter x Hunter",
        "rarity": "epic",
        "power": 12,
        "image": "https://cdn.myanimelist.net/images/characters/2/327920.jpg",
        "description": "Lightning-fast assassin"
    },
    "rengoku_kyojuro": {
        "name": "Rengoku Kyojuro",
        "anime": "Demon Slayer",
        "rarity": "epic",
        "power": 11,
        "image": "https://cdn.myanimelist.net/images/characters/12/421018.jpg",
        "description": "Flame Hashira with burning spirit"
    },
    "erza_scarlet": {
        "name": "Erza Scarlet",
        "anime": "Fairy Tail",
        "rarity": "epic",
        "power": 10,
        "image": "https://cdn.myanimelist.net/images/characters/5/81315.jpg",
        "description": "Requip magic knight"
    },
    "naruto_uzumaki": {
        "name": "Naruto Uzumaki",
        "anime": "Naruto",
        "rarity": "epic",
        "power": 13,
        "image": "https://cdn.myanimelist.net/images/characters/2/284121.jpg",
        "description": "Seventh Hokage with Nine-Tails"
    },
    "monkey_d_luffy": {
        "name": "Monkey D. Luffy",
        "anime": "One Piece",
        "rarity": "epic",
        "power": 12,
        "image": "https://cdn.myanimelist.net/images/characters/9/310307.jpg",
        "description": "Rubber pirate seeking One Piece"
    },
    "giyu_tomioka": {
        "name": "Giyu Tomioka",
        "anime": "Demon Slayer",
        "rarity": "epic",
        "power": 10,
        "image": "https://cdn.myanimelist.net/images/characters/15/421063.jpg",
        "description": "Water Hashira"
    },
    "gon_freecss": {
        "name": "Gon Freecss",
        "anime": "Hunter x Hunter",
        "rarity": "epic",
        "power": 11,
        "image": "https://cdn.myanimelist.net/images/characters/11/174517.jpg",
        "description": "Young hunter seeking his father"
    },

    # Legendary Characters (5% drop rate)
    "gojo_satoru": {
        "name": "Gojo Satoru",
        "anime": "Jujutsu Kaisen",
        "rarity": "legendary",
        "power": 20,
        "image": "https://cdn.myanimelist.net/images/characters/15/422168.jpg",
        "description": "Strongest jujutsu sorcerer"
    },
    "madara_uchiha": {
        "name": "Madara Uchiha",
        "anime": "Naruto",
        "rarity": "legendary",
        "power": 18,
        "image": "https://cdn.myanimelist.net/images/characters/10/284134.jpg",
        "description": "Legendary Uchiha clan leader"
    },
    "zeno_sama": {
        "name": "Zeno",
        "anime": "Dragon Ball",
        "rarity": "legendary",
        "power": 25,
        "image": "https://cdn.myanimelist.net/images/characters/12/348432.jpg",
        "description": "Omni-King of all universes"
    },
    "saitama": {
        "name": "Saitama",
        "anime": "One Punch Man",
        "rarity": "legendary",
        "power": 22,
        "image": "https://cdn.myanimelist.net/images/characters/11/294388.jpg",
        "description": "Hero who defeats enemies in one punch"
    },
    "rimuru_tempest": {
        "name": "Rimuru Tempest",
        "anime": "That Time I Got Reincarnated as a Slime",
        "rarity": "legendary",
        "power": 19,
        "image": "https://cdn.myanimelist.net/images/characters/5/369151.jpg",
        "description": "Slime demon lord"
    },
    "aizen_sosuke": {
        "name": "Aizen Sosuke",
        "anime": "Bleach",
        "rarity": "legendary",
        "power": 17,
        "image": "https://cdn.myanimelist.net/images/characters/7/63756.jpg",
        "description": "Former Soul Society captain"
    }
}

# Anime series completion bonuses
ANIME_SERIES = {
    "Naruto": ["sakura_haruno", "hinata_hyuga", "sasuke_uchiha", "naruto_uzumaki", "madara_uchiha"],
    "Dragon Ball": ["krillin", "yamcha", "vegeta", "zeno_sama"],
    "One Piece": ["chopper", "usopp", "roronoa_zoro", "monkey_d_luffy"],
    "Demon Slayer": ["tanjiro_kamado", "nezuko_kamado", "rengoku_kyojuro", "giyu_tomioka"],
    "Attack on Titan": ["levi_ackerman", "mikasa_ackerman"],
    "Hunter x Hunter": ["killua_zoldyck", "gon_freecss"],
    "Bleach": ["orihime_inoue", "ichigo_kurosaki", "aizen_sosuke"]
}

# Rarity configurations
RARITY_CONFIG = {
    "common": {
        "emoji": "🟢",
        "drop_rate": 50,
        "multiplier": 1.0,
        "passive_bonus": 0
    },
    "rare": {
        "emoji": "🔵", 
        "drop_rate": 30,
        "multiplier": 1.5,
        "passive_bonus": 1
    },
    "epic": {
        "emoji": "🟣",
        "drop_rate": 15,
        "multiplier": 2.0,
        "passive_bonus": 2
    },
    "legendary": {
        "emoji": "🟡",
        "drop_rate": 5,
        "multiplier": 3.0,
        "passive_bonus": 5
    }
}

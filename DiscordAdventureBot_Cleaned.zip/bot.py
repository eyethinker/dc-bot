"""
Discord bot with social, gaming, and economy features
Includes persistent data storage and comprehensive error handling
"""

import discord
from discord.ext import commands, tasks
import random
import asyncio
from datetime import datetime, timedelta
import json
import io
import logging
import aiohttp
from data_manager import DataManager
from config import BOT_TOKEN, COMMAND_PREFIX
from waifu_data import WAIFU_DATABASE, RARITY_CONFIG, ANIME_SERIES

# Configure logging
logger = logging.getLogger(__name__)

# Bot intents and initialization
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=COMMAND_PREFIX, intents=intents)

# Initialize data manager
data_manager = DataManager()

# Global flag game state
current_flag_country = None
current_flag_msg_id = None
flag_game_task = None

# Drop credits game state
dropped_credits = 0
dropper_id = None
picked_by = None

# Gang system state
gang_invitations = {}  # {user_id: {"gang_name": str, "owner_id": str, "channel": channel_id}}

# Lootbox system state
current_lootbox = None  # {"code": str, "amount": int, "message": discord.Message, "expires_at": datetime}
lootbox_task = None

# Waifu trade system state
pending_trades = {}  # {user_id: {"trader": str, "waifu": str, "credits": int, "message": discord.Message}}

# Country flags dictionary (extended from original)
COUNTRIES = {
    "afghanistan": "https://flagcdn.com/w320/af.png",
    "albania": "https://flagcdn.com/w320/al.png",
    "algeria": "https://flagcdn.com/w320/dz.png",
    "andorra": "https://flagcdn.com/w320/ad.png",
    "angola": "https://flagcdn.com/w320/ao.png",
    "antigua and barbuda": "https://flagcdn.com/w320/ag.png",
    "argentina": "https://flagcdn.com/w320/ar.png",
    "armenia": "https://flagcdn.com/w320/am.png",
    "australia": "https://flagcdn.com/w320/au.png",
    "austria": "https://flagcdn.com/w320/at.png",
    "azerbaijan": "https://flagcdn.com/w320/az.png",
    "bahamas": "https://flagcdn.com/w320/bs.png",
    "bahrain": "https://flagcdn.com/w320/bh.png",
    "bangladesh": "https://flagcdn.com/w320/bd.png",
    "barbados": "https://flagcdn.com/w320/bb.png",
    "belarus": "https://flagcdn.com/w320/by.png",
    "belgium": "https://flagcdn.com/w320/be.png",
    "belize": "https://flagcdn.com/w320/bz.png",
    "benin": "https://flagcdn.com/w320/bj.png",
    "bhutan": "https://flagcdn.com/w320/bt.png",
    "bolivia": "https://flagcdn.com/w320/bo.png",
    "bosnia and herzegovina": "https://flagcdn.com/w320/ba.png",
    "botswana": "https://flagcdn.com/w320/bw.png",
    "brazil": "https://flagcdn.com/w320/br.png",
    "brunei": "https://flagcdn.com/w320/bn.png",
    "bulgaria": "https://flagcdn.com/w320/bg.png",
    "burkina faso": "https://flagcdn.com/w320/bf.png",
    "burundi": "https://flagcdn.com/w320/bi.png",
    "cabo verde": "https://flagcdn.com/w320/cv.png",
    "cambodia": "https://flagcdn.com/w320/kh.png",
    "cameroon": "https://flagcdn.com/w320/cm.png",
    "canada": "https://flagcdn.com/w320/ca.png",
    "central african republic": "https://flagcdn.com/w320/cf.png",
    "chad": "https://flagcdn.com/w320/td.png",
    "chile": "https://flagcdn.com/w320/cl.png",
    "china": "https://flagcdn.com/w320/cn.png",
    "colombia": "https://flagcdn.com/w320/co.png",
    "comoros": "https://flagcdn.com/w320/km.png",
    "congo (brazzaville)": "https://flagcdn.com/w320/cg.png",
    "congo (kinshasa)": "https://flagcdn.com/w320/cd.png",
    "costa rica": "https://flagcdn.com/w320/cr.png",
    "croatia": "https://flagcdn.com/w320/hr.png",
    "cuba": "https://flagcdn.com/w320/cu.png",
    "cyprus": "https://flagcdn.com/w320/cy.png",
    "czech republic": "https://flagcdn.com/w320/cz.png",
    "denmark": "https://flagcdn.com/w320/dk.png",
    "djibouti": "https://flagcdn.com/w320/dj.png",
    "dominica": "https://flagcdn.com/w320/dm.png",
    "dominican republic": "https://flagcdn.com/w320/do.png",
    "ecuador": "https://flagcdn.com/w320/ec.png",
    "egypt": "https://flagcdn.com/w320/eg.png",
    "el salvador": "https://flagcdn.com/w320/sv.png",
    "equatorial guinea": "https://flagcdn.com/w320/gq.png",
    "eritrea": "https://flagcdn.com/w320/er.png",
    "estonia": "https://flagcdn.com/w320/ee.png",
    "eswatini": "https://flagcdn.com/w320/sz.png",
    "ethiopia": "https://flagcdn.com/w320/et.png",
    "fiji": "https://flagcdn.com/w320/fj.png",
    "finland": "https://flagcdn.com/w320/fi.png",
    "france": "https://flagcdn.com/w320/fr.png",
    "gabon": "https://flagcdn.com/w320/ga.png",
    "gambia": "https://flagcdn.com/w320/gm.png",
    "georgia": "https://flagcdn.com/w320/ge.png",
    "germany": "https://flagcdn.com/w320/de.png",
    "ghana": "https://flagcdn.com/w320/gh.png",
    "greece": "https://flagcdn.com/w320/gr.png",
    "grenada": "https://flagcdn.com/w320/gd.png",
    "guatemala": "https://flagcdn.com/w320/gt.png",
    "guinea": "https://flagcdn.com/w320/gn.png",
    "guinea-bissau": "https://flagcdn.com/w320/gw.png",
    "guyana": "https://flagcdn.com/w320/gy.png",
    "haiti": "https://flagcdn.com/w320/ht.png",
    "honduras": "https://flagcdn.com/w320/hn.png",
    "hungary": "https://flagcdn.com/w320/hu.png",
    "iceland": "https://flagcdn.com/w320/is.png",
    "india": "https://flagcdn.com/w320/in.png",
    "indonesia": "https://flagcdn.com/w320/id.png",
    "iran": "https://flagcdn.com/w320/ir.png",
    "iraq": "https://flagcdn.com/w320/iq.png",
    "ireland": "https://flagcdn.com/w320/ie.png",
    "israel": "https://flagcdn.com/w320/il.png",
    "italy": "https://flagcdn.com/w320/it.png",
    "ivory coast": "https://flagcdn.com/w320/ci.png",
    "jamaica": "https://flagcdn.com/w320/jm.png",
    "japan": "https://flagcdn.com/w320/jp.png",
    "jordan": "https://flagcdn.com/w320/jo.png",
    "kazakhstan": "https://flagcdn.com/w320/kz.png",
    "kenya": "https://flagcdn.com/w320/ke.png",
    "kiribati": "https://flagcdn.com/w320/ki.png",
    "kuwait": "https://flagcdn.com/w320/kw.png",
    "kyrgyzstan": "https://flagcdn.com/w320/kg.png",
    "laos": "https://flagcdn.com/w320/la.png",
    "latvia": "https://flagcdn.com/w320/lv.png",
    "lebanon": "https://flagcdn.com/w320/lb.png",
    "lesotho": "https://flagcdn.com/w320/ls.png",
    "liberia": "https://flagcdn.com/w320/lr.png",
    "libya": "https://flagcdn.com/w320/ly.png",
    "liechtenstein": "https://flagcdn.com/w320/li.png",
    "lithuania": "https://flagcdn.com/w320/lt.png",
    "luxembourg": "https://flagcdn.com/w320/lu.png",
    "madagascar": "https://flagcdn.com/w320/mg.png",
    "malawi": "https://flagcdn.com/w320/mw.png",
    "malaysia": "https://flagcdn.com/w320/my.png",
    "maldives": "https://flagcdn.com/w320/mv.png",
    "mali": "https://flagcdn.com/w320/ml.png",
    "malta": "https://flagcdn.com/w320/mt.png",
    "marshall islands": "https://flagcdn.com/w320/mh.png",
    "mauritania": "https://flagcdn.com/w320/mr.png",
    "mauritius": "https://flagcdn.com/w320/mu.png",
    "mexico": "https://flagcdn.com/w320/mx.png",
    "micronesia": "https://flagcdn.com/w320/fm.png",
    "moldova": "https://flagcdn.com/w320/md.png",
    "monaco": "https://flagcdn.com/w320/mc.png",
    "mongolia": "https://flagcdn.com/w320/mn.png",
    "montenegro": "https://flagcdn.com/w320/me.png",
    "morocco": "https://flagcdn.com/w320/ma.png",
    "mozambique": "https://flagcdn.com/w320/mz.png",
    "myanmar": "https://flagcdn.com/w320/mm.png",
    "namibia": "https://flagcdn.com/w320/na.png",
    "nauru": "https://flagcdn.com/w320/nr.png",
    "nepal": "https://flagcdn.com/w320/np.png",
    "netherlands": "https://flagcdn.com/w320/nl.png",
    "new zealand": "https://flagcdn.com/w320/nz.png",
    "nicaragua": "https://flagcdn.com/w320/ni.png",
    "niger": "https://flagcdn.com/w320/ne.png",
    "nigeria": "https://flagcdn.com/w320/ng.png",
    "north korea": "https://flagcdn.com/w320/kp.png",
    "north macedonia": "https://flagcdn.com/w320/mk.png",
    "norway": "https://flagcdn.com/w320/no.png",
    "oman": "https://flagcdn.com/w320/om.png",
    "pakistan": "https://flagcdn.com/w320/pk.png",
    "palau": "https://flagcdn.com/w320/pw.png",
    "panama": "https://flagcdn.com/w320/pa.png",
    "papua new guinea": "https://flagcdn.com/w320/pg.png",
    "paraguay": "https://flagcdn.com/w320/py.png",
    "peru": "https://flagcdn.com/w320/pe.png",
    "philippines": "https://flagcdn.com/w320/ph.png",
    "poland": "https://flagcdn.com/w320/pl.png",
    "portugal": "https://flagcdn.com/w320/pt.png",
    "qatar": "https://flagcdn.com/w320/qa.png",
    "romania": "https://flagcdn.com/w320/ro.png",
    "russia": "https://flagcdn.com/w320/ru.png",
    "rwanda": "https://flagcdn.com/w320/rw.png",
    "saint kitts and nevis": "https://flagcdn.com/w320/kn.png",
    "saint lucia": "https://flagcdn.com/w320/lc.png",
    "saint vincent and the grenadines": "https://flagcdn.com/w320/vc.png",
    "samoa": "https://flagcdn.com/w320/ws.png",
    "san marino": "https://flagcdn.com/w320/sm.png",
    "sao tome and principe": "https://flagcdn.com/w320/st.png",
    "saudi arabia": "https://flagcdn.com/w320/sa.png",
    "senegal": "https://flagcdn.com/w320/sn.png",
    "serbia": "https://flagcdn.com/w320/rs.png",
    "seychelles": "https://flagcdn.com/w320/sc.png",
    "sierra leone": "https://flagcdn.com/w320/sl.png",
    "singapore": "https://flagcdn.com/w320/sg.png",
    "slovakia": "https://flagcdn.com/w320/sk.png",
    "slovenia": "https://flagcdn.com/w320/si.png",
    "solomon islands": "https://flagcdn.com/w320/sb.png",
    "somalia": "https://flagcdn.com/w320/so.png",
    "south africa": "https://flagcdn.com/w320/za.png",
    "south korea": "https://flagcdn.com/w320/kr.png",
    "south sudan": "https://flagcdn.com/w320/ss.png",
    "spain": "https://flagcdn.com/w320/es.png",
    "sri lanka": "https://flagcdn.com/w320/lk.png",
    "sudan": "https://flagcdn.com/w320/sd.png",
    "suriname": "https://flagcdn.com/w320/sr.png",
    "sweden": "https://flagcdn.com/w320/se.png",
    "switzerland": "https://flagcdn.com/w320/ch.png",
    "syria": "https://flagcdn.com/w320/sy.png",
    "taiwan": "https://flagcdn.com/w320/tw.png",
    "tajikistan": "https://flagcdn.com/w320/tj.png",
    "tanzania": "https://flagcdn.com/w320/tz.png",
    "thailand": "https://flagcdn.com/w320/th.png",
    "timor-leste": "https://flagcdn.com/w320/tl.png",
    "togo": "https://flagcdn.com/w320/tg.png",
    "tonga": "https://flagcdn.com/w320/to.png",
    "trinidad and tobago": "https://flagcdn.com/w320/tt.png",
    "tunisia": "https://flagcdn.com/w320/tn.png",
    "turkey": "https://flagcdn.com/w320/tr.png",
    "turkmenistan": "https://flagcdn.com/w320/tm.png",
    "tuvalu": "https://flagcdn.com/w320/tv.png",
    "uganda": "https://flagcdn.com/w320/ug.png",
    "ukraine": "https://flagcdn.com/w320/ua.png",
    "united arab emirates": "https://flagcdn.com/w320/ae.png",
    "united kingdom": "https://flagcdn.com/w320/gb.png",
    "united states": "https://flagcdn.com/w320/us.png",
    "uruguay": "https://flagcdn.com/w320/uy.png",
    "uzbekistan": "https://flagcdn.com/w320/uz.png",
    "vanuatu": "https://flagcdn.com/w320/vu.png",
    "vatican city": "https://flagcdn.com/w320/va.png",
    "venezuela": "https://flagcdn.com/w320/ve.png",
    "vietnam": "https://flagcdn.com/w320/vn.png",
    "yemen": "https://flagcdn.com/w320/ye.png",
    "zambia": "https://flagcdn.com/w320/zm.png",
    "zimbabwe": "https://flagcdn.com/w320/zw.png"
}

@bot.event
async def on_ready():
    """Bot startup event"""
    logger.info(f'{bot.user} has logged in and is ready!')
    logger.info(f'Bot is in {len(bot.guilds)} guilds')

    # Start auto-save task
    auto_save.start()

    # Start lootbox spawning task
    spawn_lootbox.start()

@bot.event
async def on_command_error(ctx, error):
    """Global error handler for bot commands"""
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("❌ Command not found! Use `.help` to see available commands.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing required argument: {error.param}")
    elif isinstance(error, commands.BadArgument):
        await ctx.send("❌ Invalid argument provided. Please check your input.")
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(f"⏰ Command is on cooldown. Try again in {error.retry_after:.2f} seconds.")
    else:
        logger.error(f"Unexpected error in command {ctx.command}: {error}")
        await ctx.send("❌ An unexpected error occurred. Please try again later.")

@tasks.loop(minutes=5)
async def auto_save():
    """Automatically save data every 5 minutes"""
    try:
        data_manager.save_all_data()
        logger.info("Auto-save completed successfully")
    except Exception as e:
        logger.error(f"Auto-save failed: {e}")

@tasks.loop(minutes=2)
async def spawn_lootbox():
    """Spawn a lootbox every 2 minutes in a random channel"""
    global current_lootbox, lootbox_task

    if current_lootbox is not None:
        return  # Don't spawn if one already exists

    try:
        # Get all text channels from all guilds
        all_channels = []
        for guild in bot.guilds:
            all_channels.extend([channel for channel in guild.text_channels if channel.permissions_for(guild.me).send_messages])

        if not all_channels:
            return

        # Choose random channel
        channel = random.choice(all_channels)

        # Generate random code and amount
        code = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=6))
        amount = random.randint(1000, 5000)

        embed = discord.Embed(
            title="🎁 Lootbox Appeared!",
            description=f"A wild lootbox containing **{amount:,} credits** has appeared!",
            color=0xFFD700
        )
        embed.add_field(
            name="📝 How to Claim",
            value=f"Type `.claim {code}` to claim this lootbox!\nCode: `{code}`",
            inline=False
        )
        embed.add_field(
            name="⏰ Expires",
            value="This lootbox will disappear in 1 minute if not claimed!",
            inline=False
        )

        message = await channel.send(embed=embed)

        current_lootbox = {
            "code": code,
            "amount": amount,
            "message": message,
            "expires_at": datetime.utcnow() + timedelta(minutes=1),
            "channel_id": channel.id
        }

        # Set timeout
        lootbox_task = asyncio.create_task(lootbox_timeout())

        logger.info(f"Lootbox spawned in {channel.name} with code {code} for {amount} credits")

    except Exception as e:
        logger.error(f"Error spawning lootbox: {e}")

async def lootbox_timeout():
    """Handle lootbox timeout"""
    global current_lootbox, lootbox_task

    await asyncio.sleep(60)  # 1 minute

    if current_lootbox is not None:
        try:
            embed = discord.Embed(
                title="💨 Lootbox Expired",
                description="The lootbox has disappeared! Better luck next time.",
                color=0x808080
            )
            await current_lootbox["message"].edit(embed=embed)
        except:
            pass

        current_lootbox = None
        lootbox_task = None

# Social Commands
@bot.command()
async def hug(ctx, member: discord.Member = None):
    """Give someone a warm hug"""
    if member is None:
        await ctx.send("❌ Please mention someone to hug!")
        return
    if member == ctx.author:
        await ctx.send("🤗 You hug yourself! Self-love is important!")
        return
    await ctx.send(f"(つ≧▽≦)つ {ctx.author.mention} gives a big warm hug to {member.mention}!")

@bot.command()
async def kiss(ctx, member: discord.Member = None):
    """Give someone a sweet kiss"""
    if member is None:
        await ctx.send("❌ Please mention someone to kiss!")
        return
    if member == ctx.author:
        await ctx.send("😘 You blow yourself a kiss! Very cute!")
        return
    await ctx.send(f"(づ｡◕‿‿◕｡)づ {ctx.author.mention} kisses {member.mention}! How sweet~")

@bot.command()
async def propose(ctx, member: discord.Member = None):
    """Propose to someone special"""
    if member is None:
        await ctx.send("❌ Please mention someone to propose to!")
        return
    if member == ctx.author:
        await ctx.send("💍 You propose to yourself! That's... unique!")
        return
    await ctx.send(f"💍 {ctx.author.mention} proposes to {member.mention}! Will you say yes?")

@bot.command()
async def marry(ctx, member: discord.Member = None):
    """Propose marriage to someone special"""
    if member is None:
        await ctx.send("❌ Please mention someone to propose to!")
        return
    if member == ctx.author:
        await ctx.send("💒 You propose to yourself! That's... unique!")
        return
    if member.bot:
        await ctx.send("❌ You can't marry a bot!")
        return

    proposer_id = str(ctx.author.id)
    target_id = str(member.id)

    # Check if already married
    proposer_married = data_manager.is_married(proposer_id)
    target_married = data_manager.is_married(target_id)

    if proposer_married:
        await ctx.send(f"❌ {ctx.author.mention}, you're already married!")
        return
    if target_married:
        await ctx.send(f"❌ {member.mention} is already married!")
        return

    # Send proposal
    embed = discord.Embed(
        title="💍 Marriage Proposal",
        description=f"{ctx.author.mention} is proposing to {member.mention}!",
        color=0xFF69B4
    )
    embed.add_field(
        name="💖 Proposal",
        value=f"{member.mention}, will you marry {ctx.author.mention}?\n\nType `.yes` to accept or `.no` to decline!",
        inline=False
    )
    embed.set_footer(text="This proposal will expire in 60 seconds")

    proposal_msg = await ctx.send(embed=embed)

    # Store proposal data globally for the response commands
    bot.pending_proposals = getattr(bot, 'pending_proposals', {})
    bot.pending_proposals[target_id] = {
        'proposer': proposer_id,
        'proposer_name': ctx.author.display_name,
        'target_name': member.display_name,
        'channel': ctx.channel.id,
        'message': proposal_msg
    }

    # Set timeout
    await asyncio.sleep(60)
    if target_id in bot.pending_proposals:
        del bot.pending_proposals[target_id]
        try:
            await proposal_msg.edit(embed=discord.Embed(
                title="💔 Proposal Expired",
                description="The marriage proposal has expired.",
                color=0x808080
            ))
        except:
            pass

@bot.command()
async def yes(ctx):
    """Accept a marriage proposal or gang invitation"""
    user_id = str(ctx.author.id)

    # Check for gang invitation first
    global gang_invitations
    if user_id in gang_invitations:
        invitation = gang_invitations[user_id]
        gang_name = invitation["gang_name"]

        success = data_manager.join_gang(user_id, gang_name)

        if success:
            embed = discord.Embed(
                title="🏴 Welcome to the Gang!",
                description=f"**{ctx.author.display_name}** has joined **{gang_name}**!",
                color=0x8B0000
            )
            embed.add_field(
                name="🎉 Success!",
                value="You are now a gang member!",
                inline=False
            )
            await ctx.send(embed=embed)
        else:
            await ctx.send("❌ Failed to join gang. Please try again.")

        del gang_invitations[user_id]
        return

    # Check for marriage proposal
    if not hasattr(bot, 'pending_proposals') or user_id not in bot.pending_proposals:
        await ctx.send("❌ You don't have any pending proposals!")
        return

    proposal = bot.pending_proposals[user_id]
    proposer_id = proposal['proposer']
    proposer_name = proposal['proposer_name']
    target_name = proposal['target_name']

    # Check if both users are still single
    if data_manager.is_married(proposer_id) or data_manager.is_married(user_id):
        await ctx.send("❌ One of you is already married!")
        del bot.pending_proposals[user_id]
        return

    # Perform the marriage
    success = data_manager.marry_users(proposer_id, user_id)

    if success:
        embed = discord.Embed(
            title="💒 Wedding Bells!",
            description=f"🎉 {proposer_name} and {target_name} are now married!",
            color=0xFF69B4
        )
        embed.add_field(
            name="💖 Congratulations!",
            value="May your union be filled with love and happiness!",
            inline=False
        )
        await ctx.send(embed=embed)
    else:
        await ctx.send("❌ Marriage failed. Please try again.")

    # Clean up proposal
    if user_id in bot.pending_proposals:
        del bot.pending_proposals[user_id]

@bot.command()
async def no(ctx):
    """Decline a marriage proposal or gang invitation"""
    user_id = str(ctx.author.id)

    # Check for gang invitation first
    global gang_invitations
    if user_id in gang_invitations:
        invitation = gang_invitations[user_id]
        gang_name = invitation["gang_name"]

        embed = discord.Embed(
            title="🏴 Invitation Declined",
            description=f"**{ctx.author.display_name}** has declined the invitation to join **{gang_name}**.",
            color=0x808080
        )
        await ctx.send(embed=embed)

        del gang_invitations[user_id]
        return

    # Check for marriage proposal
    if not hasattr(bot, 'pending_proposals') or user_id not in bot.pending_proposals:
        await ctx.send("❌ You don't have any pending proposals!")
        return

    proposal = bot.pending_proposals[user_id]
    proposer_name = proposal['proposer_name']
    target_name = proposal['target_name']

    embed = discord.Embed(
        title="💔 Proposal Declined",
        description=f"{target_name} has declined {proposer_name}'s marriage proposal.",
        color=0x808080
    )
    embed.add_field(
        name="😢 Better luck next time!",
        value="Love will find a way eventually...",
        inline=False
    )
    await ctx.send(embed=embed)

    # Clean up proposal
    del bot.pending_proposals[user_id]

@bot.command()
async def divorce(ctx, member: discord.Member = None):
    """Divorce your spouse"""
    if member is None:
        await ctx.send("❌ Please mention your spouse to divorce!")
        return

    user_id = str(ctx.author.id)
    target_id = str(member.id)

    # Check if both users are married to each other
    user_married_to = data_manager.is_married(user_id)
    target_married_to = data_manager.is_married(target_id)

    if not user_married_to or not target_married_to:
        await ctx.send("❌ One or both of you are not married!")
        return

    if user_married_to != target_id or target_married_to != user_id:
        await ctx.send("❌ You are not married to each other!")
        return

    # Perform the divorce
    try:
        # Remove marriage status from both users
        data_manager.divorce_users(user_id, target_id)

        embed = discord.Embed(
            title="💔 Divorce Finalized",
            description=f"{ctx.author.display_name} and {member.display_name} are now divorced.",
            color=0x808080
        )
        embed.add_field(
            name="📜 Legal Notice",
            value="Both parties are now free to remarry if they choose.",
            inline=False
        )
        await ctx.send(embed=embed)

    except Exception as e:
        logger.error(f"Error during divorce: {e}")
        await ctx.send("❌ Divorce failed. Please try again.")

@bot.command()
async def kick(ctx, member: discord.Member = None):
    """Playfully kick someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to kick!")
        return
    if member == ctx.author:
        await ctx.send("🦵 You kick yourself! Ouch!")
        return
    await ctx.send(f"👢 {ctx.author.mention} kicked {member.mention}... gently, of course!")

@bot.command()
async def slap(ctx, member: discord.Member = None):
    """Playfully slap someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to slap!")
        return
    if member == ctx.author:
        await ctx.send("👋 You slap yourself! That must hurt!")
        return
    await ctx.send(f"👋 {ctx.author.mention} slapped {member.mention}! Play nice!")

@bot.command()
async def kill(ctx, member: discord.Member = None):
    """Pretend to eliminate someone (playfully)"""
    if member is None:
        await ctx.send("❌ Please mention someone to eliminate!")
        return
    if member == ctx.author:
        await ctx.send("💀 You eliminate yourself! That's dark!")
        return
    await ctx.send(f"💀 {ctx.author.mention} just *pretended* to eliminate {member.mention}... Yikes!")

@bot.command()
async def chapal(ctx, member: discord.Member = None):
    """Throw a chapal at someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to throw a chapal at!")
        return
    if member == ctx.author:
        await ctx.send("🩴 You throw a chapal at yourself! That's... confusing!")
        return
    await ctx.send(f"🩴 {ctx.author.mention} throws a chapal at {member.mention}! *THWACK!*")

@bot.command()
async def curse(ctx, member: discord.Member = None):
    """Curse someone's whole bloodline"""
    if member is None:
        await ctx.send("❌ Please mention someone to curse!")
        return
    if member == ctx.author:
        await ctx.send("😈 You curse your own bloodline! That's... not very smart!")
        return
    await ctx.send(f"😈 {ctx.author.mention} curses {member.mention}'s whole bloodline! May chaos follow them for seven generations!")

@bot.command()
async def rps(ctx, member: discord.Member = None, bet_amount: int = 0):
    """Play rock, paper, scissors with optional betting"""
    if member is None:
        await ctx.send("❌ Please mention someone to play rock, paper, scissors with!")
        return
    if member == ctx.author:
        await ctx.send("🪨📄✂️ You can't play against yourself!")
        return
    if member.bot:
        await ctx.send("🤖 Bots don't play rock, paper, scissors!")
        return

    user_id = str(ctx.author.id)
    target_id = str(member.id)

    # Check if betting
    if bet_amount > 0:
        user_wallet = data_manager.get_credits(user_id)
        target_wallet = data_manager.get_credits(target_id)

        if user_wallet < bet_amount:
            await ctx.send(f"💸 {ctx.author.mention}, you don't have {bet_amount} credits in your wallet!")
            return
        if target_wallet < bet_amount:
            await ctx.send(f"💸 {member.mention} doesn't have {bet_amount} credits in their wallet!")
            return

    choices = ["🪨", "📄", "✂️"]
    choice_names = {"🪨": "Rock", "📄": "Paper", "✂️": "Scissors"}

    user_choice = random.choice(choices)
    target_choice = random.choice(choices)

    # Determine winner
    if user_choice == target_choice:
        result = "It's a tie!"
        winner = None
    elif (user_choice == "🪨" and target_choice == "✂️") or \
         (user_choice == "📄" and target_choice == "🪨") or \
         (user_choice == "✂️" and target_choice == "📄"):
        result = f"{ctx.author.mention} wins!"
        winner = ctx.author
    else:
        result = f"{member.mention} wins!"
        winner = member

    embed = discord.Embed(title="🪨📄✂️ Rock Paper Scissors", color=0x00ff00)
    embed.add_field(name=f"{ctx.author.display_name}", value=f"{user_choice} {choice_names[user_choice]}", inline=True)
    embed.add_field(name="VS", value="⚔️", inline=True)
    embed.add_field(name=f"{member.display_name}", value=f"{target_choice} {choice_names[target_choice]}", inline=True)
    embed.add_field(name="Result", value=result, inline=False)

    # Handle betting
    if bet_amount > 0 and winner:
        loser = member if winner == ctx.author else ctx.author
        winner_id = str(winner.id)
        loser_id = str(loser.id)

        data_manager.add_credits(loser_id, -bet_amount)
        data_manager.add_credits(winner_id, bet_amount)

        embed.add_field(name="💰 Betting Result", 
                       value=f"{winner.mention} wins {bet_amount} credits from {loser.mention}!", 
                       inline=False)
    elif bet_amount > 0:
        embed.add_field(name="💰 Betting Result", value="No credits exchanged due to tie!", inline=False)

    await ctx.send(embed=embed)

# Economy Commands
@bot.command()
async def daily(ctx):
    """Claim your daily credits (1500 credits, once per 24 hours)"""
    user_id = str(ctx.author.id)
    now = datetime.utcnow()

    last_daily = data_manager.get_daily_timestamp(user_id)
    if last_daily and now - last_daily < timedelta(days=1):
        time_left = timedelta(days=1) - (now - last_daily)
        hours = int(time_left.total_seconds() // 3600)
        minutes = int((time_left.total_seconds() % 3600) // 60)
        await ctx.send(f"🕒 You can only claim your daily credits once every 24 hours! Come back in {hours}h {minutes}m.")
        return

    base_amount = 1500
    # Apply waifu passive bonus
    passive_bonus = data_manager.get_passive_income_bonus(user_id)
    bonus_amount = int(base_amount * (passive_bonus / 100))
    total_amount = base_amount + bonus_amount
    
    data_manager.add_credits(user_id, total_amount)
    data_manager.set_daily_timestamp(user_id, now)
    
    if bonus_amount > 0:
        await ctx.send(f"✨ {ctx.author.mention}, you received {total_amount:,} daily credits! (+{bonus_amount:,} waifu bonus)")
    else:
        await ctx.send(f"✨ {ctx.author.mention}, you received {total_amount:,} daily credits!")

@bot.command()
async def work(ctx):
    """Work to earn credits (500 credits, once per hour)"""
    user_id = str(ctx.author.id)
    now = datetime.utcnow()

    last_work = data_manager.get_work_timestamp(user_id)
    if last_work and now - last_work < timedelta(hours=1):
        time_left = timedelta(hours=1) - (now - last_work)
        minutes = int(time_left.total_seconds() // 60)
        await ctx.send(f"🕐 You can only work once every hour! Come back in {minutes} minutes.")
        return

    base_amount = 500
    # Apply waifu passive bonus
    passive_bonus = data_manager.get_passive_income_bonus(user_id)
    bonus_amount = int(base_amount * (passive_bonus / 100))
    total_amount = base_amount + bonus_amount
    
    data_manager.add_credits(user_id, total_amount)
    data_manager.set_work_timestamp(user_id, now)
    
    if bonus_amount > 0:
        await ctx.send(f"💼 {ctx.author.mention}, you worked hard and earned {total_amount:,} credits! (+{bonus_amount:,} waifu bonus)")
    else:
        await ctx.send(f"💼 {ctx.author.mention}, you worked hard and earned {total_amount:,} credits!")

@bot.command()
async def dep(ctx, arg=None):
    """Deposit credits from wallet to bank"""
    if arg is None:
        await ctx.send("💳 Use `.dep all` to deposit all credits or `.dep <amount>` to deposit a specific amount.")
        return

    user_id = str(ctx.author.id)
    if arg == "all":
        wallet_credits = data_manager.get_credits(user_id)
        if wallet_credits == 0:
            await ctx.send("💸 You have no credits in your wallet to deposit!")
            return

        deposited, new_bank_balance = data_manager.deposit_to_bank(user_id)
        await ctx.send(f"🏦 {ctx.author.mention}, deposited {deposited} credits to your bank! Bank balance: {new_bank_balance} credits.")
    else:
        try:
            amount = int(arg)
            if amount <= 0:
                await ctx.send("❌ Please enter a positive amount.")
                return

            wallet_credits = data_manager.get_credits(user_id)
            if amount > wallet_credits:
                await ctx.send(f"❌ You only have {wallet_credits} credits in your wallet!")
                return

            deposited, new_bank_balance = data_manager.deposit_to_bank(user_id, amount)
            await ctx.send(f"🏦 {ctx.author.mention}, deposited {deposited} credits to your bank! Bank balance: {new_bank_balance} credits.")
        except ValueError:
            await ctx.send("❌ Please enter a valid number or 'all'.")

@bot.command()
async def leaderboard(ctx):
    """Show the top 10 richest users by total credits (wallet + bank)"""
    try:
        # Get all users' credits and bank credits
        all_credits = data_manager.get_all_credits()

        # Calculate total credits for each user (wallet + bank)
        user_totals = {}
        for user_id in all_credits.keys():
            try:
                wallet = int(data_manager.get_credits(str(user_id)) or 0)
                bank = int(data_manager.get_bank_credits(str(user_id)) or 0)
                total = wallet + bank
                if total > 0:
                    user_totals[str(user_id)] = total
            except (ValueError, TypeError):
                continue

        if not user_totals:
            await ctx.send("📊 No users have credits yet! Start earning with `.daily` or `.work`!")
            return

        # Sort by total credits
        sorted_users = sorted(user_totals.items(), key=lambda x: x[1], reverse=True)[:10]

        embed = discord.Embed(
            title="🏆 Credits Leaderboard",
            description="Top 10 richest users by total credits",
            color=0xFFD700
        )

        for i, (user_id, total_credits) in enumerate(sorted_users, 1):
            try:
                user = await bot.fetch_user(int(user_id))
                emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "💰"
                username = str(user.display_name)[:20]  # Limit length
            except Exception:
                emoji = "💰"
                username = f"User {user_id}"

            embed.add_field(
                name=f"{emoji} #{i}",
                value=f"**{username}**\n{int(total_credits):,} credits",
                inline=True
            )

        await ctx.send(embed=embed)

    except Exception as e:
        logger.error(f"Error in leaderboard command: {e}")
        await ctx.send("❌ Error displaying leaderboard. Please try again.")

@bot.command()
async def bal(ctx, member: discord.Member = None):
    """Check your or someone else's credit balance"""
    if member is None:
        member = ctx.author

    user_id = str(member.id)
    wallet_balance = data_manager.get_credits(user_id)
    bank_balance = data_manager.get_bank_credits(user_id)
    total_balance = wallet_balance + bank_balance
    has_shield = data_manager.has_shield(user_id)

    shield_status = "🛡️ Protected" if has_shield else "❌ No Shield"

    embed = discord.Embed(title=f"💰 {member.display_name}'s Balance", color=0x00ff00)
    embed.add_field(name="💳 Wallet", value=f"{wallet_balance:,} credits", inline=True)
    embed.add_field(name="🏦 Bank", value=f"{bank_balance:,} credits", inline=True)
    embed.add_field(name="💎 Total", value=f"{total_balance:,} credits", inline=True)
    embed.add_field(name="🛡️ Shield Status", value=shield_status, inline=False)
    await ctx.send(embed=embed)

# Gambling Commands
@bot.command()
async def bet(ctx, amount: int = None):
    """Bet credits with 50/50 chance to double or lose"""
    if amount is None:
        await ctx.send("❌ Please specify an amount to bet!")
        return

    user_id = str(ctx.author.id)
    balance = data_manager.get_credits(user_id)

    if amount <= 0:
        await ctx.send("❌ You must bet a positive amount!")
        return

    if balance < amount:
        await ctx.send(f"💸 You don't have enough credits to bet {amount:,}! You only have {balance:,} credits.")
        return

    data_manager.add_credits(user_id, -amount)

    if random.choice([True, False]):
        data_manager.add_credits(user_id, amount * 2)
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"🎲 {ctx.author.mention}, you won the bet! You gained {amount:,} credits! New balance: {new_balance:,}")
    else:
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"😢 {ctx.author.mention}, you lost the bet! You lost {amount:,} credits. New balance: {new_balance:,}")

@bot.command()
async def slots(ctx, amount: int = None):
    """Play the slot machine"""
    if amount is None:
        await ctx.send("❌ Please specify an amount to play slots!")
        return

    user_id = str(ctx.author.id)
    balance = data_manager.get_credits(user_id)

    if amount <= 0:
        await ctx.send("❌ You must bet a positive amount!")
        return

    if balance < amount:
        await ctx.send(f"💸 You don't have enough credits! You need {amount:,} but only have {balance:,}.")
        return

    data_manager.add_credits(user_id, -amount)
    symbols = ["🍒", "🍋", "🍉", "🍇", "🔔", "💎", "7️⃣"]
    results = [random.choice(symbols) for _ in range(3)]

    await ctx.send(f"🎰 {' | '.join(results)}")

    new_balance = data_manager.get_credits(user_id)

    if results.count(results[0]) == 3:
        # Jackpot - all three symbols match
        if results[0] == "💎":
            # Diamond jackpot - 5x multiplier
            winnings = amount * 5
            data_manager.add_credits(user_id, winnings)
            new_balance = data_manager.get_credits(user_id)
            await ctx.send(f"💎 DIAMOND JACKPOT! You win {winnings:,} credits! New balance: {new_balance:,}")
        elif results[0] == "7️⃣":
            # Lucky 7 jackpot - 4x multiplier
            winnings = amount * 4
            data_manager.add_credits(user_id, winnings)
            new_balance = data_manager.get_credits(user_id)
            await ctx.send(f"🍀 LUCKY 7 JACKPOT! You win {winnings:,} credits! New balance: {new_balance:,}")
        else:
            # Regular jackpot - 3x multiplier
            winnings = amount * 3
            data_manager.add_credits(user_id, winnings)
            new_balance = data_manager.get_credits(user_id)
            await ctx.send(f"🎉 JACKPOT! You win {winnings:,} credits! New balance: {new_balance:,}")
    elif len(set(results)) == 2:
        # Two symbols match - small win
        winnings = amount
        data_manager.add_credits(user_id, winnings)
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"🎊 Small win! You get your bet back! New balance: {new_balance:,}")
    else:
        await ctx.send(f"😬 Better luck next time! New balance: {new_balance:,}")

# Flag Game Commands
@bot.command()
async def gtf(ctx):
    """Start a guess-the-flag game"""
    global current_flag_country, current_flag_msg_id, flag_game_task

    if current_flag_country is not None:
        await ctx.send("🚩 A flag is already active! Guess it using `.flag country_name`")
        return

    current_flag_country = random.choice(list(COUNTRIES.keys()))
    flag_url = COUNTRIES[current_flag_country]

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(flag_url) as resp:
                if resp.status != 200:
                    await ctx.send("❌ Failed to fetch flag image. Please try again later.")
                    current_flag_country = None
                    return
                image_data = await resp.read()

        message = await ctx.send(
            "🌍 **Guess the flag!** 🚩\nUse `.flag country_name` to guess!\nYou have 30 seconds!",
            file=discord.File(fp=io.BytesIO(image_data), filename="flag.png")
        )
        current_flag_msg_id = message.id
        flag_game_task = asyncio.create_task(flag_timeout(ctx.channel))

        logger.info(f"Flag game started: {current_flag_country}")

    except Exception as e:
        logger.error(f"Error in flag game: {e}")
        await ctx.send("❌ Failed to start flag game. Please try again later.")
        current_flag_country = None

async def flag_timeout(channel):
    """Handle flag game timeout"""
    global current_flag_country, current_flag_msg_id, flag_game_task
    await asyncio.sleep(30)
    if current_flag_country is not None:
        await channel.send(f"⏰ Time's up! The correct country was **{current_flag_country.title()}**.")
        current_flag_country = None
        current_flag_msg_id = None
    flag_game_task = None

@bot.command()
async def flag(ctx, *, country_guess: str = None):
    """Guess the current flag"""
    global current_flag_country, flag_game_task

    if country_guess is None:
        await ctx.send("❌ Please provide a country name to guess!")
        return

    if current_flag_country is None:
        await ctx.send("🚫 There's no flag to guess right now! Start one with `.gtf`.")
        return

    guess = country_guess.lower().strip()
    if guess == current_flag_country:
        user_id = str(ctx.author.id)
        data_manager.add_credits(user_id, 100)
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"🎉 {ctx.author.mention} guessed it right! **{current_flag_country.title()}** was correct! You earned 100 credits! Balance: {new_balance:,}")
        current_flag_country = None
        current_flag_msg_id = None
        if flag_game_task:
            flag_game_task.cancel()
            flag_game_task = None
    else:
        await ctx.send(f"❌ Nope, {ctx.author.mention}! **{country_guess.title()}** is not correct. Try again!")

@bot.command()
async def skip(ctx):
    """Skip the current flag game"""
    global current_flag_country, current_flag_msg_id, flag_game_task

    if current_flag_country is None:
        await ctx.send("🚫 There's no flag to skip right now!")
        return

    await ctx.send(f"⏭️ Skipped! The correct country was **{current_flag_country.title()}**.")
    current_flag_country = None
    current_flag_msg_id = None
    if flag_game_task:
        flag_game_task.cancel()
        flag_game_task = None

# Credit Drop Commands
@bot.command()
async def drop(ctx, amount: int = None):
    """Drop credits for others to pick up"""
    global dropped_credits, dropper_id, picked_by

    if amount is None:
        await ctx.send("❌ Please specify an amount to drop!")
        return

    user_id = str(ctx.author.id)

    if dropped_credits > 0:
        await ctx.send("⚠️ A credit drop is already in progress!")
        return

    if amount <= 0:
        await ctx.send("🚫 You must drop a positive amount.")
        return

    balance = data_manager.get_credits(user_id)
    if balance < amount:
        await ctx.send(f"💸 Not enough credits to drop! You need {amount:,} but only have {balance:,}.")
        return

    data_manager.add_credits(user_id, -amount)
    dropped_credits = amount
    dropper_id = user_id
    picked_by = None

    await ctx.send(f"💸 {ctx.author.mention} dropped **{amount:,} credits**! Be the first to `.pick` it!")

@bot.command()
async def pick(ctx):
    """Pick up dropped credits"""
    global dropped_credits, dropper_id, picked_by

    user_id = str(ctx.author.id)

    if dropped_credits == 0:
        await ctx.send("📭 No credit drop is available.")
        return

    if picked_by is not None:
        await ctx.send("⌛ Too late! Someone already picked it.")
        return

    if user_id == dropper_id:
        await ctx.send("❌ You can't pick up your own dropped credits!")
        return

    picked_by = user_id
    data_manager.add_credits(user_id, dropped_credits)
    new_balance = data_manager.get_credits(user_id)

    await ctx.send(f"🎁 {ctx.author.mention} picked up **{dropped_credits:,} credits**! New balance: {new_balance:,}")

    # Reset drop state
    dropped_credits = 0
    dropper_id = None
    picked_by = None

# Utility Commands
@bot.command()
async def ping(ctx):
    """Check bot latency"""
    latency = round(bot.latency * 1000)
    await ctx.send(f"🏓 Pong! Latency: {latency}ms")

# Robbery and Shield Commands
@bot.command()
async def rob(ctx, member: discord.Member = None):
    """Rob all credits from someone's wallet (requires 500+ credits in target's wallet)"""
    if member is None:
        await ctx.send("❌ Please mention someone to rob!")
        return
    if member == ctx.author:
        await ctx.send("🤔 You can't rob yourself!")
        return
    if member.bot:
        await ctx.send("🤖 You can't rob bots!")
        return

    robber_id = str(ctx.author.id)
    target_id = str(member.id)

    success, amount_robbed = data_manager.rob_wallet(robber_id, target_id)

    if not success:
        target_wallet = data_manager.get_credits(target_id)
        if target_wallet < 500:
            await ctx.send(f"💸 {member.mention} doesn't have enough credits in their wallet to rob! (Need 500+ credits)")
        else:
            await ctx.send(f"❌ Failed to rob {member.mention}!")
    else:
        await ctx.send(f"💰 {ctx.author.mention} successfully robbed **{amount_robbed:,} credits** from {member.mention}'s wallet! 💸")

@bot.command()
async def steal(ctx, member: discord.Member = None):
    """Attempt to steal 50% of credits from someone's bank (luck-based)"""
    if member is None:
        await ctx.send("❌ Please mention someone to steal from!")
        return
    if member == ctx.author:
        await ctx.send("🤔 You can't steal from yourself!")
        return
    if member.bot:
        await ctx.send("🤖 You can't steal from bots!")
        return

    thief_id = str(ctx.author.id)
    target_id = str(member.id)

    # Check if target has active shield
    if data_manager.has_shield(target_id):
        time_left = data_manager.get_shield_time_left(target_id)
        if time_left > 0:
            hours = int(time_left // 3600)
            minutes = int((time_left % 3600) // 60)
            await ctx.send(f"🛡️ {member.mention}'s shield is still active! Shield time remaining: {hours}h {minutes}m")
            return

    # Random luck factor (50% chance)
    if random.choice([True, False]):
        success, amount_stolen = data_manager.steal_from_bank(thief_id, target_id)

        if not success:
            await ctx.send(f"💸 {member.mention} doesn't have any credits in their bank to steal!")
        else:
            await ctx.send(f"🎯 {ctx.author.mention} successfully stole **{amount_stolen:,} credits** from {member.mention}'s bank! 💰")
    else:
        await ctx.send(f"❌ {ctx.author.mention} failed to steal from {member.mention}! Better luck next time! 🎲")

@bot.command()
async def shield(ctx):
    """Buy shield protection for 500 credits (lasts 5 hours)"""
    user_id = str(ctx.author.id)

    if data_manager.has_shield(user_id):
        time_left = data_manager.get_shield_time_left(user_id)
        if time_left > 0:
            hours = int(time_left // 3600)
            minutes = int((time_left % 3600) // 60)
            await ctx.send(f"🛡️ You already have shield protection! Time remaining: {hours}h {minutes}m")
            return

    success = data_manager.buy_shield(user_id)

    if not success:
        wallet_balance = data_manager.get_credits(user_id)
        await ctx.send(f"💸 You need 500 credits in your wallet to buy a shield! You have {wallet_balance:,} credits.")
    else:
        await ctx.send(f"🛡️ {ctx.author.mention} bought shield protection for 500 credits! You're now protected from stealing for 5 hours.")

@bot.command()
async def take(ctx, amount: int = None):
    """Withdraw credits from bank to wallet"""
    if amount is None:
        await ctx.send("💳 Please specify the amount to withdraw from your bank. Usage: `.take <amount>`")
        return

    if amount <= 0:
        await ctx.send("❌ Please enter a positive amount!")
        return

    user_id = str(ctx.author.id)
    bank_balance = data_manager.get_bank_credits(user_id)

    if bank_balance < amount:
        await ctx.send(f"💸 You don't have enough credits in your bank! Bank balance: {bank_balance:,} credits.")
        return

    success, new_wallet_balance = data_manager.withdraw_from_bank(user_id, amount)

    if success:
        await ctx.send(f"🏦 {ctx.author.mention} withdrew {amount:,} credits from bank to wallet! Wallet balance: {new_wallet_balance:,} credits.")
    else:
        await ctx.send("❌ Failed to withdraw credits from bank!")

@bot.command()
async def give(ctx, member: discord.Member = None, amount: int = None):
    """Give credits to another user (from your wallet)"""
    if member is None:
        await ctx.send("❌ Please mention someone to give credits to!")
        return
    if member == ctx.author:
        await ctx.send("🤔 You can't give credits to yourself!")
        return
    if member.bot:
        await ctx.send("🤖 You can't give credits to bots!")
        return
    if amount is None:
        await ctx.send("💳 Please specify the amount to give. Usage: `.give @user <amount>`")
        return
    if amount <= 0:
        await ctx.send("❌ Please enter a positive amount!")
        return

    giver_id = str(ctx.author.id)
    receiver_id = str(member.id)

    success, message = data_manager.give_credits(giver_id, receiver_id, amount)

    if success:
        await ctx.send(f"💰 {ctx.author.mention} gave {amount:,} credits to {member.mention}! 🎁")
    else:
        await ctx.send(f"❌ {ctx.author.mention}, {message}")

@bot.command(name='bothelp')
async def help(ctx, command_name: str = None):
    """Show help information"""
    if command_name is None:
        embed = discord.Embed(
            title="🤖 Bot Commands Help",
            description="Here are all available commands:",
            color=0x00ff00
        )

        embed.add_field(
            name="💖 Social Commands",
            value="`.hug @user` - Give a hug\n`.kiss @user` - Give a kiss\n`.propose @user` - Propose marriage\n`.marry @user` - Get married\n`.kick @user` - Playful kick\n`.slap @user` - Playful slap\n`.kill @user` - Pretend elimination",
            inline=False
        )

        embed.add_field(
            name="💰 Economy Commands",
            value="`.daily` - Get 1500 daily credits\n`.work` - Work for 500 credits (1h cooldown)\n`.bal [@user]` - Check balance\n`.leaderboard` - Top 10 richest users\n`.dep <amount|all>` - Deposit credits",
            inline=False
        )

        embed.add_field(
            name="🎲 Gambling Commands",
            value="`.bet <amount>` - 50/50 chance to double\n`.slots <amount>` - Play slot machine\n`.flip <amount>` - Flip coin, double or lose\n`.bj <amount>` - Play blackjack",
            inline=False
        )

        embed.add_field(
            name="🚩 Flag Game Commands",
            value="`.gtf` - Start flag guessing game\n`.flag <country>` - Guess the flag\n`.skip` - Skip current flag",
            inline=False
        )

        embed.add_field(
            name="💸 Credit Drop Commands",
            value="`.drop <amount>` - Drop credits for others\n`.pick` - Pick up dropped credits",
            inline=False
        )

        embed.add_field(
            name="🛒 Shop & Pet Commands",
            value="`.shop` - Browse shop\n`.buypet <type> <name>` - Buy a pet\n`.pet` - Show pet status\n`.attack @user` - Attack pet\n`.revive` - Revive dead pet\n`.nickname <name>` - Rename pet",
            inline=False
        )

        embed.add_field(
            name="💕 Social Commands",
            value="`.pat @user` - Pat someone\n`.meow @user` - Meow for someone\n`.rwrr @user` - Rwrr at someone\n`.shush @user` - Tell someone to shush\n`.adopt @user` - Adopt someone\n`.runaway` - Run away and vanish",
            inline=False
        )

        embed.add_field(
            name="🔥 Fun Analysis Commands",
            value="`.roast @user` - Serve a spicy roast 🔥\n`.delulu @user` - Check delusion level 🌀\n`.toxicrate @user` - Check toxicity level ☠️\n`.braincell @user` - Count braincells 🧠💥\n`.npc @user` - Test if someone is an NPC 🤖",
            inline=False
        )

        embed.add_field(
            name="🏴 Gang Commands",
            value="`.create <name>` - Create gang (10k credits)\n`.add @user` - Invite to gang\n`.gang` - Show gang info\n`.gdep <amount>` - Deposit to gang\n`.gtake <amount>` - Withdraw (owner)\n`.glogo <url>` - Set gang logo\n`.gleaderboard` - Gang rankings",
            inline=False
        )

        embed.add_field(
            name="🎁 Lootbox Commands",
            value="`.claim <code>` - Claim lootbox\n*Lootboxes appear randomly every 2 minutes!*",
            inline=False
        )

        embed.add_field(
            name="👤 Profile Commands",
            value="`.profile [@user]` - Show user profile",
            inline=False
        )

        embed.add_field(
            name="👁️ Server Commands",
            value="`.eye [@user]` - Welcome to server vision with cute message",
            inline=False
        )

        embed.add_field(
            name="💞 Waifu/Husbando System",
            value="`.summon` - Summon random character (500 credits)\n`.waifulist [@user]` - View collection\n`.flexwaifu @user` - Show strongest character\n`.release <name>` - Release for 100 credits\n`.setbonus` - Check collection bonuses\n`.waifubattle @user` - Battle strongest characters\n`.trade @user <name>` - Propose character trade",
            inline=False
        )

        embed.add_field(
            name="🔧 Utility Commands",
            value="`.ping` - Check bot latency\n`.help [command]` - Show this help",
            inline=False
        )

        await ctx.send(embed=embed)
    else:
        # Show help for specific command
        command = bot.get_command(command_name)
        if command is None:
            await ctx.send(f"❌ Command `{command_name}` not found!")
            return

        embed = discord.Embed(
            title=f"Help: {command.name}",
            description=command.help or "No description available.",
            color=0x00ff00
        )

        if command.usage:
            embed.add_field(name="Usage", value=f"`.{command.name} {command.usage}`", inline=False)

        await ctx.send(embed=embed)

@bot.command()
async def pet(ctx):
    """Show your pet's status"""
    user_id = str(ctx.author.id)
    pet = data_manager.get_user_pet(user_id)

    if not pet:
        await ctx.send("❌ You don't have a pet! Use `.shop` to buy one.")
        return

    pet_images = {
        "ant": "https://i.imgur.com/K7zKzKz.png",
        "cat": "https://i.imgur.com/mXyUpV7.png", 
        "panda": "https://i.imgur.com/QrKjQvJ.png",
        "tiger": "https://i.imgur.com/vHwDgNY.png",
        "butterfly": "https://i.imgur.com/8yFqDxU.png"
    }

    status = "Alive 💚" if pet.get("alive", False) else "Dead 💀"
    hp_bar = "█" * (pet['hp'] // (pet['max_hp'] // 10)) + "░" * (10 - (pet['hp'] // (pet['max_hp'] // 10)))

    embed = discord.Embed(
        title=f"🐾 {pet['name']}'s Status",
        color=0x00FF00 if pet.get("alive", False) else 0xFF0000
    )

    embed.set_thumbnail(url=pet_images.get(pet['type'], ""))

    embed.add_field(
        name="Pet Type",
        value=pet['type'].title(),
        inline=True
    )

    embed.add_field(
        name="Status",
        value=status,
        inline=True
    )

    embed.add_field(
        name="Attack Power",
        value=f"⚔️ {pet['attack']}",
        inline=True
    )

    embed.add_field(
        name="Health",
        value=f"❤️ {pet['hp']}/{pet['max_hp']}\n{hp_bar}",
        inline=False
    )

    if not pet.get("alive", False):
        embed.add_field(
            name="Revival",
            value="Use `.revive` to bring your pet back to life for 150 credits!",
            inline=False
        )

    await ctx.send(embed=embed)

# New Commands Implementation

@bot.command()
async def flip(ctx, amount: int = None, choice: str = None):
    """Flip a coin - choose heads or tails to double your bet or lose it all"""
    if amount is None:
        await ctx.send("❌ Please specify an amount and choice! Usage: `.flip <amount> <heads/tails>`")
        return

    if choice is None:
        await ctx.send("❌ Please choose heads or tails! Usage: `.flip <amount> <heads/tails>`")
        return

    if amount <= 0:
        await ctx.send("❌ Amount must be positive!")
        return

    choice = choice.lower()
    if choice not in ["heads", "tails"]:
        await ctx.send("❌ Please choose either 'heads' or 'tails'!")
        return

    user_id = str(ctx.author.id)
    current_credits = data_manager.get_credits(user_id)

    if current_credits < amount:
        await ctx.send(f"❌ Insufficient credits! You have {current_credits} credits.")
        return

    # Flip the coin
    result = random.choice(["heads", "tails"])

    if result == choice:
        # Win - double the bet
        winnings = amount * 2
        data_manager.add_credits(user_id, amount)  # Add the winnings
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"🪙 **{result.upper()}!** You chose {choice} and won! +{winnings} credits! Balance: {new_balance}")
    else:
        # Lose - lose the bet
        data_manager.add_credits(user_id, -amount)
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"🪙 **{result.upper()}!** You chose {choice} but lost {amount} credits! Balance: {new_balance}")

@bot.command()
async def shop(ctx):
    """Browse the shop for shields and pets"""
    embed = discord.Embed(
        title="🛒 Twinkii Shop",
        description="Buy shields and pets with your credits!",
        color=0x00FF00
    )

    embed.add_field(
        name="🛡️ Shield Protection",
        value="**Price:** 500 credits\n**Effect:** Protects against bank stealing",
        inline=False
    )

    embed.add_field(
        name="🐜 Ant Pet",
        value="**Price:** 100 credits\n**HP:** 10 | **Attack:** 2",
        inline=True
    )

    embed.add_field(
        name="🐱 Cat Pet",
        value="**Price:** 300 credits\n**HP:** 25 | **Attack:** 5",
        inline=True
    )

    embed.add_field(
        name="🐼 Panda Pet",
        value="**Price:** 600 credits\n**HP:** 40 | **Attack:** 8",
        inline=True
    )

    embed.add_field(
        name="🐅 Tiger Pet",
        value="**Price:** 1000 credits\n**HP:** 60 | **Attack:** 12",
        inline=True
    )

    embed.add_field(
        name="🦋 Butterfly Pet",
        value="**Price:** 200 credits\n**HP:** 15 | **Attack:** 3",
        inline=True
    )

    embed.add_field(
        name="💊 Revival Potion",
        value="**Price:** 150 credits\n**Effect:** Revive your dead pet",
        inline=True
    )

    embed.add_field(
        name="How to Buy:",
        value="**Shield:** `.shield`\n**Pet:** `.buypet <type> <name>`\n**Potion:** `.revive`",
        inline=False
    )

    await ctx.send(embed=embed)

@bot.command()
async def buypet(ctx, pet_type: str = None, *, pet_name: str = None):
    """Buy a pet from the shop"""
    if pet_type is None or pet_name is None:
        await ctx.send("❌ Usage: `.buypet <type> <name>`\nAvailable types: ant, cat, panda, tiger, butterfly")
        return

    pet_type = pet_type.lower()
    pet_prices = {
        "ant": 100,
        "cat": 300,
        "panda": 600,
        "tiger": 1000,
        "butterfly": 200
    }

    if pet_type not in pet_prices:
        await ctx.send("❌ Invalid pet type! Available: ant, cat, panda, tiger, butterfly")
        return

    user_id = str(ctx.author.id)
    existing_pet = data_manager.get_user_pet(user_id)

    if existing_pet:
        await ctx.send("❌ You already have a pet! You can only own one pet at a time.")
        return

    cost = pet_prices[pet_type]

    if data_manager.buy_pet(user_id, pet_type, pet_name, cost):
        pet_emojis = {"ant": "🐜", "cat": "🐱", "panda": "🐼", "tiger": "🐅", "butterfly": "🦋"}
        await ctx.send(f"🎉 Congratulations! You bought a {pet_emojis[pet_type]} **{pet_name}** for {cost} credits!")
    else:
        await ctx.send(f"❌ Insufficient credits! You need {cost} credits to buy a {pet_type}.")

@bot.command()
async def attack(ctx, member: discord.Member = None):
    """Attack another user's pet with your pet"""
    if member is None:
        await ctx.send("❌ Please mention a user to attack! Usage: `.attack @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("❌ You can't attack your own pet!")
        return

    attacker_id = str(ctx.author.id)
    target_id = str(member.id)

    success, message = data_manager.attack_pet(attacker_id, target_id)

    if success:
        await ctx.send(f"⚔️ **Pet Battle!**\n{message}")
    else:
        await ctx.send(f"❌ {message}")

@bot.command()
async def revive(ctx):
    """Revive your dead pet with a potion"""
    user_id = str(ctx.author.id)
    cost = 150

    if data_manager.revive_pet(user_id, cost):
        pet = data_manager.get_user_pet(user_id)
        await ctx.send(f"💊 **{pet['name']}** has been revived! Welcome back to life! 🎉")
    else:
        pet = data_manager.get_user_pet(user_id)
        if not pet:
            await ctx.send("❌ You don't have a pet to revive!")
        elif pet.get("alive", False):
            await ctx.send("❌ Your pet is already alive!")
        else:
            await ctx.send(f"❌ You need {cost} credits to buy a revival potion!")

@bot.command()
async def nickname(ctx, *, new_name: str = None):
    """Change your pet's nickname"""
    if new_name is None:
        await ctx.send("❌ Please provide a new name! Usage: `.nickname <new name>`")
        return

    user_id = str(ctx.author.id)

    if data_manager.nickname_pet(user_id, new_name):
        await ctx.send(f"✨ Your pet's name has been changed to **{new_name}**!")
    else:
        await ctx.send("❌ You don't have a pet to rename!")

@bot.command()
async def spit(ctx, member: discord.Member = None):
    """Spit on someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to spit on! Usage: `.spit @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("💧 You spit on yourself... that's weird.")
        return

    responses = [
        f"💧 {ctx.author.mention} spits on {member.mention}! *Eww!*",
        f"💧 {ctx.author.mention} hocks a loogie at {member.mention}! *Disgusting!*",
        f"💧 {ctx.author.mention} spits in {member.mention}'s direction! *How rude!*"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def love(ctx, member: discord.Member = None):
    """Show love to someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to show love! Usage: `.love @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("💖 You love yourself! That's important for self-care!")
        return

    responses = [
        f"💖 {ctx.author.mention} shows love to {member.mention}! *So sweet!*",
        f"💕 {ctx.author.mention} sends loving vibes to {member.mention}! *Aww!*",
        f"💗 {ctx.author.mention} expresses their love for {member.mention}! *Heartwarming!*"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def lick(ctx, member: discord.Member = None):
    """Lick someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to lick! Usage: `.lick @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("👅 You lick yourself... that's... interesting.")
        return

    responses = [
        f"👅 {ctx.author.mention} licks {member.mention}! *Weird but okay...*",
        f"👅 {ctx.author.mention} gives {member.mention} a big lick! *Slobbery!*",
        f"👅 {ctx.author.mention} licks {member.mention} like a puppy! *So strange!*"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def pat(ctx, member: discord.Member = None):
    """Pat someone gently"""
    if member is None:
        await ctx.send("❌ Please mention someone to pat! Usage: `.pat @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("🤗 You pat yourself on the head! Good job!")
        return

    responses = [
        f"🫳 {ctx.author.mention} gently pats {member.mention} on the head! *So wholesome!*",
        f"🫳 {ctx.author.mention} gives {member.mention} a comforting pat! *Very sweet!*",
        f"🫳 {ctx.author.mention} pats {member.mention} affectionately! *Aww!*"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def meow(ctx, member: discord.Member = None):
    """Meow for someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to meow for! Usage: `.meow @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("🐱 You meow at yourself... meow?")
        return

    responses = [
        f"🐱 {ctx.author.mention} meows for {member.mention}! *Meow meow~*",
        f"🐱 {ctx.author.mention} makes cute cat sounds for {member.mention}! *Nya~*",
        f"🐱 {ctx.author.mention} purrs and meows at {member.mention}! *So adorable!*"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def rwrr(ctx, member: discord.Member = None):
    """Rwrr at someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to rwrr at! Usage: `.rwrr @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("🦁 You rwrr at yourself... intimidating!")
        return

    responses = [
        f"🦁 {ctx.author.mention} rwrrs at {member.mention}! *RWRRR!*",
        f"🦁 {ctx.author.mention} makes fierce tiger sounds at {member.mention}! *Rawr!*",
        f"🦁 {ctx.author.mention} growls playfully at {member.mention}! *RWRR RWRR!*"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def shush(ctx, member: discord.Member = None):
    """Tell someone to shush"""
    if member is None:
        await ctx.send("❌ Please mention someone to shush! Usage: `.shush @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("🤫 You shush yourself... very quiet!")
        return

    responses = [
        f"🤫 {ctx.author.mention} tells {member.mention} to shush! *Shhhhh!*",
        f"🤫 {ctx.author.mention} puts a finger to their lips at {member.mention}! *Quiet down!*",
        f"🤫 {ctx.author.mention} shushes {member.mention}! *Be quiet!*"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def adopt(ctx, member: discord.Member = None):
    """Adopt someone as your child"""
    if member is None:
        await ctx.send("❌ Please mention someone to adopt! Usage: `.adopt @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("👶 You adopt yourself... that's confusing!")
        return

    responses = [
        f"👶 {ctx.author.mention} adopts {member.mention}! Welcome to the family!",
        f"👨‍👩‍👧‍👦 {ctx.author.mention} officially adopts {member.mention}! You're family now!",
        f"🏠 {ctx.author.mention} brings {member.mention} into their family through adoption!"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def runaway(ctx):
    """Run away and vanish dramatically"""
    responses = [
        f"🏃‍♂️💨 {ctx.author.mention} runs away into the distance and vanishes! *Poof!*",
        f"👻 {ctx.author.mention} disappears in a cloud of smoke! Where did they go?",
        f"🌪️ {ctx.author.mention} spins around and vanishes into thin air!",
        f"🏃‍♀️💨 {ctx.author.mention} runs off into the sunset, never to be seen again!"
    ]

    await ctx.send(random.choice(responses))

@bot.command()
async def roast(ctx, member: discord.Member = None):
    """Serve a spicy roast to someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to roast! Usage: `.roast @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("🔥 You roast yourself... that's some self-burn!")
        return

    roasts = [
        f"🔥 {ctx.author.mention} roasts {member.mention}: You're like a software update - nobody wants you, but you keep showing up anyway!",
        f"🔥 {ctx.author.mention} serves {member.mention}: If you were any more dense, you'd collapse into a black hole!",
        f"🔥 {ctx.author.mention} burns {member.mention}: You're proof that evolution can go in reverse!",
        f"🔥 {ctx.author.mention} roasts {member.mention}: You're like a participation trophy - everyone gets one, but nobody wants yours!",
        f"🔥 {ctx.author.mention} flames {member.mention}: I'd explain it to you, but I don't have any crayons with me!"
    ]

    await ctx.send(random.choice(roasts))

@bot.command()
async def delulu(ctx, member: discord.Member = None):
    """Check how delusional someone is"""
    if member is None:
        member = ctx.author

    delulu_level = random.randint(1, 100)
    
    if delulu_level <= 20:
        status = "Pretty grounded! 🧠"
    elif delulu_level <= 40:
        status = "Slightly dreamy 🌙"
    elif delulu_level <= 60:
        status = "Living in fantasyland 🦄"
    elif delulu_level <= 80:
        status = "Maximum delusion mode! 🌀"
    else:
        status = "ABSOLUTELY UNHINGED! 🤯"

    await ctx.send(f"🌀 **Delusion Meter**: {member.mention} is **{delulu_level}%** delulu! {status}")

@bot.command()
async def toxicrate(ctx, member: discord.Member = None):
    """Find out how toxic someone is"""
    if member is None:
        member = ctx.author

    toxic_level = random.randint(1, 100)
    
    if toxic_level <= 20:
        status = "Pure angel! 😇"
    elif toxic_level <= 40:
        status = "Mildly spicy 🌶️"
    elif toxic_level <= 60:
        status = "Getting toxic! ☠️"
    elif toxic_level <= 80:
        status = "Danger zone! ⚠️"
    else:
        status = "NUCLEAR WASTE! ☢️"

    await ctx.send(f"☠️ **Toxicity Meter**: {member.mention} is **{toxic_level}%** toxic! {status}")

@bot.command()
async def braincell(ctx, member: discord.Member = None):
    """Check how many braincells someone has left"""
    if member is None:
        member = ctx.author

    braincells = random.randint(0, 10)
    
    if braincells == 0:
        status = "All gone! 💥"
    elif braincells <= 2:
        status = "Running on fumes! 🔥"
    elif braincells <= 5:
        status = "Half capacity 🧠"
    elif braincells <= 8:
        status = "Pretty smart! 🤓"
    else:
        status = "Big brain energy! 🧠✨"

    await ctx.send(f"🧠💥 **Braincell Count**: {member.mention} has **{braincells}** braincells left! {status}")

@bot.command()
async def npc(ctx, member: discord.Member = None):
    """Test if someone is an NPC"""
    if member is None:
        member = ctx.author

    npc_level = random.randint(1, 100)
    
    if npc_level <= 20:
        status = "Definitely a main character! 🌟"
    elif npc_level <= 40:
        status = "Side character vibes 👤"
    elif npc_level <= 60:
        status = "Background NPC energy 🤖"
    elif npc_level <= 80:
        status = "Total NPC behavior! 🎮"
    else:
        status = "PURE NPC! *Has 3 dialogue options* 🤖"

    await ctx.send(f"🤖 **NPC Test**: {member.mention} is **{npc_level}%** NPC! {status}")

@bot.command()
async def bj(ctx, amount: int = None):
    """Play interactive blackjack to win or lose credits"""
    if amount is None:
        await ctx.send("❌ Please specify an amount to bet! Usage: `.bj <amount>`")
        return

    if amount <= 0:
        await ctx.send("❌ Amount must be positive!")
        return

    user_id = str(ctx.author.id)
    current_credits = data_manager.get_credits(user_id)

    if current_credits < amount:
        await ctx.send(f"❌ Insufficient credits! You have {current_credits} credits.")
        return

    # Card deck simulation
    def draw_card():
        cards = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11]  # J, Q, K = 10, A = 11
        return random.choice(cards)

    def calculate_total(cards):
        total = sum(cards)
        aces = cards.count(11)
        while total > 21 and aces:
            total -= 10
            aces -= 1
        return total

    # Initial deal
    player_cards = [draw_card(), draw_card()]
    dealer_cards = [draw_card(), draw_card()]

    player_total = calculate_total(player_cards)
    dealer_shown = dealer_cards[0]

    # Show initial hands
    embed = discord.Embed(title="🃏 Blackjack Game", color=0x00FF00)
    embed.add_field(
        name="Your Hand",
        value=f"Cards: {player_cards}\nTotal: {player_total}",
        inline=True
    )
    embed.add_field(
        name="Dealer's Hand",
        value=f"Shown: {dealer_shown}\nHidden: ?",
        inline=True
    )
    embed.add_field(
        name="Options",
        value="Type `hit` to draw another card or `stand` to stay",
        inline=False
    )

    await ctx.send(embed=embed)

    # Check for natural blackjack
    if player_total == 21:
        dealer_total = calculate_total(dealer_cards)
        if dealer_total == 21:
            await ctx.send(f"🤝 **Both have blackjack!** Tie! Cards: You {player_cards} vs Dealer {dealer_cards}")
            return
        else:
            winnings = int(amount * 1.5)
            data_manager.add_credits(user_id, winnings)
            new_balance = data_manager.get_credits(user_id)
            await ctx.send(f"🎉 **BLACKJACK!** You won {winnings} credits! Balance: {new_balance}")
            return

    # Player's turn
    def check_response(message):
        return message.author == ctx.author and message.channel == ctx.channel and message.content.lower() in ['hit', 'stand']

    try:
        while player_total < 21:
            response = await bot.wait_for('message', check=check_response, timeout=30.0)

            if response.content.lower() == 'hit':
                new_card = draw_card()
                player_cards.append(new_card)
                player_total = calculate_total(player_cards)

                if player_total > 21:
                    data_manager.add_credits(user_id, -amount)
                    new_balance = data_manager.get_credits(user_id)
                    await ctx.send(f"💸 **BUST!** Total: {player_total} with {player_cards}\nYou lost {amount} credits! Balance: {new_balance}")
                    return
                elif player_total == 21:
                    await ctx.send(f"Perfect 21! Cards: {player_cards}")
                    break
                else:
                    await ctx.send(f"Hit! New card: {new_card}. Total: {player_total}. Cards: {player_cards}\nType `hit` or `stand`")

            elif response.content.lower() == 'stand':
                await ctx.send(f"You stand with {player_total}. Dealer's turn...")
                break

    except asyncio.TimeoutError:
        await ctx.send("⏰ Time's up! Auto-standing...")

    # Dealer's turn
    dealer_total = calculate_total(dealer_cards)
    while dealer_total < 17:
        dealer_cards.append(draw_card())
        dealer_total = calculate_total(dealer_cards)

    # Determine winner
    if dealer_total > 21:
        winnings = amount * 2
        data_manager.add_credits(user_id, amount)
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"🎉 **Dealer BUST!** Dealer: {dealer_total} {dealer_cards}\nYou won {winnings} credits! Balance: {new_balance}")
    elif player_total > dealer_total:
        winnings = amount * 2
        data_manager.add_credits(user_id, amount)
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"🎉 **YOU WIN!** You: {player_total} vs Dealer: {dealer_total}\nYou won {winnings} credits! Balance: {new_balance}")
    elif player_total == dealer_total:
        await ctx.send(f"🤝 **TIE!** Both have {player_total}. No credits lost or gained!")
    else:
        data_manager.add_credits(user_id, -amount)
        new_balance = data_manager.get_credits(user_id)
        await ctx.send(f"💸 **DEALER WINS!** You: {player_total} vs Dealer: {dealer_total}\nYou lost {amount} credits! Balance: {new_balance}")

# Gang System Commands
@bot.command()
async def create(ctx, *, gang_name: str = None):
    """Create a gang for 10,000 credits"""
    if gang_name is None:
        await ctx.send("❌ Please provide a gang name! Usage: `.create <gang_name>`")
        return

    user_id = str(ctx.author.id)

    # Check if user already owns a gang
    if data_manager.get_user_gang(user_id):
        await ctx.send("❌ You already belong to a gang!")
        return

    # Check if gang name already exists
    if data_manager.gang_exists(gang_name):
        await ctx.send(f"❌ Gang name '{gang_name}' already exists!")
        return

    # Check if user has enough credits
    if data_manager.get_credits(user_id) < 10000:
        balance = data_manager.get_credits(user_id)
        await ctx.send(f"❌ You need 10,000 credits to create a gang! You have {balance:,} credits.")
        return

    # Create gang
    success = data_manager.create_gang(user_id, gang_name)

    if success:
        embed = discord.Embed(
            title="🏴 Gang Created!",
            description=f"**{gang_name}** has been created successfully!",
            color=0x8B0000
        )
        embed.add_field(
            name="👑 Leader",
            value=ctx.author.display_name,
            inline=True
        )
        embed.add_field(
            name="💰 Cost",
            value="10,000 credits deducted",
            inline=True
        )
        embed.add_field(
            name="📋 Next Steps",
            value="Use `.add @user` to invite members!\nUse `.glogo <url>` to set a logo!",
            inline=False
        )
        await ctx.send(embed=embed)
    else:
        await ctx.send("❌ Failed to create gang. Please try again.")

@bot.command()
async def add(ctx, member: discord.Member = None):
    """Invite a user to your gang"""
    global gang_invitations

    if member is None:
        await ctx.send("❌ Please mention someone to invite! Usage: `.add @user`")
        return

    if member.id == ctx.author.id:
        await ctx.send("❌ You can't invite yourself!")
        return

    if member.bot:
        await ctx.send("❌ You can't invite bots to gangs!")
        return

    inviter_id = str(ctx.author.id)
    target_id = str(member.id)

    # Check if inviter is gang owner
    gang = data_manager.get_user_gang(inviter_id)
    if not gang or gang.get("role") != "owner":
        await ctx.send("❌ Only gang owners can invite members!")
        return

    # Check if target is already in a gang
    if data_manager.get_user_gang(target_id):
        await ctx.send(f"❌ {member.mention} is already in a gang!")
        return

    # Check if target already has a pending invitation
    if target_id in gang_invitations:
        await ctx.send(f"❌ {member.mention} already has a pending gang invitation!")
        return

    gang_name = gang["gang_name"]

    # Send invitation
    embed = discord.Embed(
        title="🏴 Gang Invitation",
        description=f"{member.mention}, you've been invited to join **{gang_name}**!",
        color=0x8B0000
    )
    embed.add_field(
        name="👑 Invited by",
        value=ctx.author.display_name,
        inline=True
    )
    embed.add_field(
        name="🏴 Gang",
        value=gang_name,
        inline=True
    )
    embed.add_field(
        name="📋 Response",
        value="Type `.yes` to accept or `.no` to decline!\n⏰ This invitation expires in 60 seconds.",
        inline=False
    )

    invitation_msg = await ctx.send(embed=embed)

    # Store invitation
    gang_invitations[target_id] = {
        "gang_name": gang_name,
        "owner_id": inviter_id,
        "channel": ctx.channel.id,
        "message": invitation_msg
    }

    # Set timeout
    await asyncio.sleep(60)
    if target_id in gang_invitations:
        del gang_invitations[target_id]
        try:
            await invitation_msg.edit(embed=discord.Embed(
                title="💔 Invitation Expired",
                description="The gang invitation has expired.",
                color=0x808080
            ))
        except:
            pass

@bot.command()
async def gang(ctx):
    """Show your gang information"""
    user_id = str(ctx.author.id)
    gang_info = data_manager.get_gang_info(user_id)

    if not gang_info:
        await ctx.send("❌ You're not in a gang! Use `.create <name>` to create one or wait for an invitation.")
        return

    gang_name = gang_info["gang_name"]
    members = gang_info["members"]
    total_bank = gang_info["total_bank"]
    logo_url = gang_info.get("logo_url", "")

    embed = discord.Embed(
        title=f"🏴 {gang_name}",
        description=f"Gang Bank: **{total_bank:,} credits**",
        color=0x8B0000
    )

    if logo_url and logo_url.startswith(('http://', 'https://')):
        try:
            embed.set_image(url=logo_url)
        except:
            pass

    # Add members sorted by contribution
    members_text = ""
    for i, (member_id, member_data) in enumerate(sorted(members.items(), key=lambda x: x[1]["contributed"], reverse=True), 1):
        try:
            user = await bot.fetch_user(int(member_id))
            role_emoji = "👑" if member_data["role"] == "owner" else "👤"
            members_text += f"{role_emoji} **{user.display_name}**: {member_data['contributed']:,} credits\n"
        except:
            members_text += f"👤 **Unknown User**: {member_data['contributed']:,} credits\n"

    if members_text:
        embed.add_field(
            name=f"👥 Members ({len(members)})",
            value=members_text,
            inline=False
        )

    await ctx.send(embed=embed)

@bot.command()
async def gdep(ctx, amount: int = None):
    """Deposit credits to gang bank"""
    if amount is None:
        await ctx.send("❌ Please specify an amount! Usage: `.gdep <amount>`")
        return

    if amount <= 0:
        await ctx.send("❌ Amount must be positive!")
        return

    user_id = str(ctx.author.id)

    # Check if user is in a gang
    if not data_manager.get_user_gang(user_id):
        await ctx.send("❌ You're not in a gang!")
        return

    # Check if user has enough credits
    if data_manager.get_credits(user_id) < amount:
        balance = data_manager.get_credits(user_id)
        await ctx.send(f"❌ You don't have enough credits! You have {balance:,} credits.")
        return

    success, new_contribution = data_manager.deposit_to_gang(user_id, amount)

    if success:
        gang_info = data_manager.get_gang_info(user_id)
        await ctx.send(f"🏦 {ctx.author.mention} deposited {amount:,} credits to **{gang_info['gang_name']}**!\nYour total contribution: {new_contribution:,} credits")
    else:
        await ctx.send("❌ Failed to deposit to gang bank!")

@bot.command()
async def gleaderboard(ctx):
    """Show gang leaderboard by total bank credits"""
    leaderboard = data_manager.get_gang_leaderboard()

    if not leaderboard:
        await ctx.send("📊 No gangs exist yet! Use `.create <name>` to create the first gang!")
        return

    embed = discord.Embed(
        title="🏆 Gang Leaderboard",
        description="Top gangs by total bank credits",
        color=0x8B0000
    )

    for i, gang_data in enumerate(leaderboard[:10], 1):
        gang_name = gang_data["gang_name"]
        total_bank = gang_data["total_bank"]
        member_count = gang_data["member_count"]
        logo_url = gang_data.get("logo_url", "")

        emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "🏴"

        value_text = f"**{gang_name}**\n{total_bank:,} credits\n{member_count} members"

        embed.add_field(
            name=f"{emoji} #{i}",
            value=value_text,
            inline=True
        )

        # Set the image to the #1 gang's logo
        if i == 1 and logo_url and logo_url.startswith(('http://', 'https://')):
            try:
                embed.set_image(url=logo_url)
            except:
                pass

    await ctx.send(embed=embed)

@bot.command()
async def gtake(ctx, amount: int = None):
    """Withdraw credits from gang bank (owner only)"""
    if amount is None:
        await ctx.send("❌ Please specify an amount! Usage: `.gtake <amount>`")
        return

    if amount <= 0:
        await ctx.send("❌ Amount must be positive!")
        return

    user_id = str(ctx.author.id)
    gang = data_manager.get_user_gang(user_id)

    if not gang:
        await ctx.send("❌ You're not in a gang!")
        return

    if gang.get("role") != "owner":
        await ctx.send("❌ Only gang owners can withdraw from the gang bank!")
        return

    success, new_balance = data_manager.withdraw_from_gang(user_id, amount)

    if success:
        gang_info = data_manager.get_gang_info(user_id)
        await ctx.send(f"💰 {ctx.author.mention} withdrew {amount:,} credits from **{gang_info['gang_name']}** bank!\nYour wallet balance: {new_balance:,} credits")
    else:
        gang_info = data_manager.get_gang_info(user_id)
        gang_bank = gang_info["total_bank"] if gang_info else 0
        await ctx.send(f"❌ Insufficient gang bank credits! Gang bank has {gang_bank:,} credits.")

@bot.command()
async def leave(ctx):
    """Leave your current gang"""
    user_id = str(ctx.author.id)
    gang = data_manager.get_user_gang(user_id)

    if not gang:
        await ctx.send("❌ You're not in a gang!")
        return

    if gang.get("role") == "owner":
        await ctx.send("❌ Gang owners cannot leave their gang! You must transfer ownership or disband the gang.")
        return

    gang_name = gang["gang_name"]
    success = data_manager.leave_gang(user_id)

    if success:
        embed = discord.Embed(
            title="🚪 Left Gang",
            description=f"**{ctx.author.display_name}** has left **{gang_name}**.",
            color=0x808080
        )
        embed.add_field(
            name="👋 Goodbye",
            value="You are no longer a member of this gang.",
            inline=False
        )
        await ctx.send(embed=embed)
    else:
        await ctx.send("❌ Failed to leave gang. Please try again.")

@bot.command()
async def glogo(ctx, *, logo_url: str = None):
    """Set gang logo (owner only)"""
    if logo_url is None:
        await ctx.send("❌ Please provide a logo URL! Usage: `.glogo <image_url>`")
        return

    user_id = str(ctx.author.id)
    gang = data_manager.get_user_gang(user_id)

    if not gang:
        await ctx.send("❌ You're not in a gang!")
        return

    if gang.get("role") != "owner":
        await ctx.send("❌ Only gang owners can set the gang logo!")
        return

    # Validate URL format
    if not logo_url.startswith(('http://', 'https://')):
        await ctx.send("❌ Please provide a valid URL starting with http:// or https://")
        return

    success = data_manager.set_gang_logo(user_id, logo_url)

    if success:
        gang_info = data_manager.get_gang_info(user_id)
        embed = discord.Embed(
            title=f"🖼️ Logo Updated for {gang_info['gang_name']}",
            description="Gang logo has been successfully updated!",
            color=0x8B0000
        )
        try:
            embed.set_image(url=logo_url)
        except:
            pass
        await ctx.send(embed=embed)
    else:
        await ctx.send("❌ Failed to set gang logo!")

# Lootbox Commands
@bot.command()
async def claim(ctx, code: str = None):
    """Claim a lootbox with the correct code"""
    global current_lootbox, lootbox_task

    if code is None:
        await ctx.send("❌ Please provide the lootbox code! Usage: `.claim <code>`")
        return

    if current_lootbox is None:
        await ctx.send("❌ No lootbox is currently available!")
        return

    if code.upper() != current_lootbox["code"]:
        await ctx.send(f"❌ Incorrect code! The correct code is `{current_lootbox['code']}`")
        return

    # Check if lootbox expired
    if datetime.utcnow() > current_lootbox["expires_at"]:
        await ctx.send("❌ This lootbox has expired!")
        current_lootbox = None
        if lootbox_task:
            lootbox_task.cancel()
            lootbox_task = None
        return

    # Award credits
    user_id = str(ctx.author.id)
    amount = current_lootbox["amount"]
    data_manager.add_credits(user_id, amount)
    new_balance = data_manager.get_credits(user_id)

    # Update lootbox message
    try:
        embed = discord.Embed(
            title="🎉 Lootbox Claimed!",
            description=f"**{ctx.author.display_name}** claimed the lootbox and received **{amount:,} credits**!",
            color=0x00FF00
        )
        embed.add_field(
            name="🎁 Claimed by",
            value=ctx.author.mention,
            inline=True
        )
        embed.add_field(
            name="💰 Amount",
            value=f"{amount:,} credits",
            inline=True
        )
        await current_lootbox["message"].edit(embed=embed)
    except:
        pass

    await ctx.send(f"🎁 {ctx.author.mention} claimed the lootbox and received **{amount:,} credits**! New balance: {new_balance:,}")

    # Clean up
    current_lootbox = None
    if lootbox_task:
        lootbox_task.cancel()
        lootbox_task = None

# Waifu/Husbando Gacha System Commands
@bot.command()
async def summon(ctx):
    """Summon a random waifu/husbando for 500 credits"""
    user_id = str(ctx.author.id)
    
    if data_manager.get_credits(user_id) < 500:
        balance = data_manager.get_credits(user_id)
        await ctx.send(f"❌ You need 500 credits to summon! You have {balance:,} credits.")
        return
    
    # Deduct credits
    data_manager.add_credits(user_id, -500)
    
    # Determine rarity based on drop rates
    import random
    roll = random.randint(1, 100)
    
    if roll <= 5:  # 5% legendary
        rarity = "legendary"
    elif roll <= 20:  # 15% epic (5% + 15% = 20%)
        rarity = "epic"
    elif roll <= 50:  # 30% rare (20% + 30% = 50%)
        rarity = "rare"
    else:  # 50% common
        rarity = "common"
    
    # Get characters of this rarity
    available_waifus = {k: v for k, v in WAIFU_DATABASE.items() if v["rarity"] == rarity}
    
    if not available_waifus:
        await ctx.send("❌ No characters available for this rarity!")
        return
    
    # Select random character
    waifu_id = random.choice(list(available_waifus.keys()))
    waifu_data = available_waifus[waifu_id].copy()
    
    # Add to user's collection
    data_manager.add_waifu_to_collection(user_id, waifu_id, waifu_data)
    
    # Create embed
    rarity_emoji = RARITY_CONFIG[rarity]["emoji"]
    embed = discord.Embed(
        title=f"🎰 Waifu Summoned!",
        description=f"**{waifu_data['name']}** joined your collection!",
        color=0xFF69B4
    )
    
    embed.add_field(
        name="📊 Stats",
        value=f"{rarity_emoji} **{rarity.title()}**\n⚔️ Power: {waifu_data['power']}\n📺 Anime: {waifu_data['anime']}",
        inline=True
    )
    
    embed.add_field(
        name="📝 Description", 
        value=waifu_data["description"],
        inline=False
    )
    
    embed.set_image(url=waifu_data["image"])
    embed.set_footer(text=f"You spent 500 credits • Collection growing!")
    
    await ctx.send(embed=embed)

@bot.command()
async def waifulist(ctx, member: discord.Member = None):
    """View your or someone else's waifu collection"""
    if member is None:
        member = ctx.author
    
    user_id = str(member.id)
    user_waifus = data_manager.get_user_waifus(user_id)
    
    if not user_waifus:
        await ctx.send(f"❌ {member.display_name} doesn't have any waifus yet! Use `.summon` to start collecting.")
        return
    
    # Sort by rarity and power
    rarity_order = {"legendary": 0, "epic": 1, "rare": 2, "common": 3}
    sorted_waifus = sorted(
        user_waifus.items(),
        key=lambda x: (rarity_order.get(x[1]["rarity"], 4), -x[1]["power"])
    )
    
    embed = discord.Embed(
        title=f"👑 {member.display_name}'s Waifu Collection",
        description=f"Total: {len(user_waifus)} characters",
        color=0xFF1493
    )
    
    # Add characters to embed (max 25 fields)
    for i, (waifu_id, waifu_data) in enumerate(sorted_waifus[:25], 1):
        rarity_emoji = RARITY_CONFIG[waifu_data["rarity"]]["emoji"]
        embed.add_field(
            name=f"{i}. {waifu_data['name']}",
            value=f"{rarity_emoji} {waifu_data['rarity'].title()} • ⚔️ {waifu_data['power']}",
            inline=True
        )
    
    if len(user_waifus) > 25:
        embed.set_footer(text=f"Showing 25 of {len(user_waifus)} characters")
    
    await ctx.send(embed=embed)

@bot.command()
async def flexwaifu(ctx, member: discord.Member = None):
    """Show off your strongest waifu to someone"""
    if member is None:
        await ctx.send("❌ Please mention someone to flex to! Usage: `.flexwaifu @user`")
        return
    
    user_id = str(ctx.author.id)
    strongest_id, strongest_data = data_manager.get_strongest_waifu(user_id)
    
    if not strongest_data:
        await ctx.send("❌ You don't have any waifus to flex! Use `.summon` to get some.")
        return
    
    rarity_emoji = RARITY_CONFIG[strongest_data["rarity"]]["emoji"]
    embed = discord.Embed(
        title=f"💪 {ctx.author.display_name} flexes their strongest waifu!",
        description=f"Look at this {strongest_data['rarity']} waifu, {member.mention}!",
        color=0xFFD700
    )
    
    embed.add_field(
        name="👑 Strongest Character",
        value=f"**{strongest_data['name']}**\n{rarity_emoji} {strongest_data['rarity'].title()}\n⚔️ Power: {strongest_data['power']}\n📺 {strongest_data['anime']}",
        inline=False
    )
    
    embed.set_image(url=strongest_data["image"])
    embed.set_footer(text=f"Flexing to {member.display_name}")
    
    await ctx.send(embed=embed)

@bot.command()
async def release(ctx, *, waifu_name: str = None):
    """Release a waifu for 100 credits"""
    if waifu_name is None:
        await ctx.send("❌ Please specify which waifu to release! Usage: `.release <waifu name>`")
        return
    
    user_id = str(ctx.author.id)
    user_waifus = data_manager.get_user_waifus(user_id)
    
    # Find waifu by name
    waifu_id = None
    waifu_data = None
    for wid, wdata in user_waifus.items():
        if wdata["name"].lower() == waifu_name.lower():
            waifu_id = wid
            waifu_data = wdata
            break
    
    if not waifu_id:
        await ctx.send(f"❌ You don't have a waifu named '{waifu_name}' in your collection!")
        return
    
    # Remove from collection and give credits
    data_manager.remove_waifu_from_collection(user_id, waifu_id)
    data_manager.add_credits(user_id, 100)
    new_balance = data_manager.get_credits(user_id)
    
    embed = discord.Embed(
        title="👋 Waifu Released",
        description=f"You released **{waifu_data['name']}** and received 100 credits!",
        color=0x808080
    )
    embed.add_field(
        name="💰 Credits",
        value=f"New balance: {new_balance:,} credits",
        inline=False
    )
    
    await ctx.send(embed=embed)

@bot.command()
async def setbonus(ctx):
    """Check completed anime series and passive bonuses"""
    user_id = str(ctx.author.id)
    completed_series = data_manager.get_user_completed_series(user_id)
    passive_bonus = data_manager.get_passive_income_bonus(user_id)
    
    embed = discord.Embed(
        title="🏆 Collection Bonuses",
        description=f"{ctx.author.display_name}'s anime achievements",
        color=0x00FF00
    )
    
    if completed_series:
        series_text = "\n".join([f"✅ {series}" for series in completed_series])
        embed.add_field(
            name="📺 Completed Series",
            value=series_text,
            inline=False
        )
        
        # Calculate series bonus
        series_bonus = len(completed_series) * 2000
        embed.add_field(
            name="🎉 Series Completion Reward",
            value=f"{series_bonus:,} bonus credits earned!",
            inline=True
        )
    else:
        embed.add_field(
            name="📺 Completed Series",
            value="None yet - collect all characters from one anime!",
            inline=False
        )
    
    embed.add_field(
        name="🧠 Passive Income Bonus",
        value=f"+{passive_bonus}% to .work, .daily commands",
        inline=True
    )
    
    # Show what's needed for completion
    incomplete_series = []
    user_waifus = data_manager.get_user_waifus(user_id)
    user_waifu_ids = set(user_waifus.keys())
    
    for series_name, required_waifus in ANIME_SERIES.items():
        if series_name not in completed_series:
            missing = [WAIFU_DATABASE[wid]["name"] for wid in required_waifus if wid not in user_waifu_ids]
            if missing:
                incomplete_series.append(f"**{series_name}**: {', '.join(missing[:3])}{'...' if len(missing) > 3 else ''}")
    
    if incomplete_series:
        embed.add_field(
            name="📋 Series Progress",
            value="\n".join(incomplete_series[:5]),
            inline=False
        )
    
    await ctx.send(embed=embed)

@bot.command()
async def waifubattle(ctx, member: discord.Member = None):
    """Battle another user's strongest waifu (1 hour cooldown)"""
    if member is None:
        await ctx.send("❌ Please mention someone to battle! Usage: `.waifubattle @user`")
        return
    
    if member.id == ctx.author.id:
        await ctx.send("❌ You can't battle yourself!")
        return
    
    if member.bot:
        await ctx.send("❌ You can't battle bots!")
        return
    
    user_id = str(ctx.author.id)
    target_id = str(member.id)
    
    # Check cooldown
    last_battle = data_manager.get_waifu_battle_timestamp(user_id)
    if last_battle and datetime.utcnow() - last_battle < timedelta(hours=1):
        time_left = timedelta(hours=1) - (datetime.utcnow() - last_battle)
        minutes = int(time_left.total_seconds() // 60)
        await ctx.send(f"⏰ You can only battle once per hour! Come back in {minutes} minutes.")
        return
    
    # Get strongest waifus
    user_waifu_id, user_waifu = data_manager.get_strongest_waifu(user_id)
    target_waifu_id, target_waifu = data_manager.get_strongest_waifu(target_id)
    
    if not user_waifu:
        await ctx.send("❌ You don't have any waifus to battle with! Use `.summon` to get some.")
        return
    
    if not target_waifu:
        await ctx.send(f"❌ {member.mention} doesn't have any waifus to battle!")
        return
    
    # Calculate battle power (power + rarity multiplier + random factor)
    user_power = user_waifu["power"] * RARITY_CONFIG[user_waifu["rarity"]]["multiplier"]
    target_power = target_waifu["power"] * RARITY_CONFIG[target_waifu["rarity"]]["multiplier"]
    
    # Add randomness (±20%)
    user_final_power = user_power * random.uniform(0.8, 1.2)
    target_final_power = target_power * random.uniform(0.8, 1.2)
    
    # Determine winner
    if user_final_power > target_final_power:
        winner = ctx.author
        winner_waifu = user_waifu
        loser = member
        loser_waifu = target_waifu
        data_manager.add_credits(user_id, 1000)
    else:
        winner = member
        winner_waifu = target_waifu
        loser = ctx.author
        loser_waifu = user_waifu
        data_manager.add_credits(target_id, 1000)
    
    # Set cooldown
    data_manager.set_waifu_battle_timestamp(user_id, datetime.utcnow())
    
    # Battle result embed
    embed = discord.Embed(
        title="⚔️ Waifu Battle!",
        description=f"**{ctx.author.display_name}** vs **{member.display_name}**",
        color=0xFF4500
    )
    
    embed.add_field(
        name=f"{ctx.author.display_name}'s Fighter",
        value=f"**{user_waifu['name']}**\n{RARITY_CONFIG[user_waifu['rarity']]['emoji']} {user_waifu['rarity'].title()}\n⚔️ Power: {user_power:.1f}",
        inline=True
    )
    
    embed.add_field(
        name="VS",
        value="⚔️",
        inline=True
    )
    
    embed.add_field(
        name=f"{member.display_name}'s Fighter", 
        value=f"**{target_waifu['name']}**\n{RARITY_CONFIG[target_waifu['rarity']]['emoji']} {target_waifu['rarity'].title()}\n⚔️ Power: {target_power:.1f}",
        inline=True
    )
    
    embed.add_field(
        name="🏆 Battle Result",
        value=f"**{winner.display_name}** wins with **{winner_waifu['name']}**!\n💰 +1000 credits!",
        inline=False
    )
    
    # Add some flavor text
    battle_quotes = [
        f"An epic clash! {winner_waifu['name']}'s power overwhelmed {loser_waifu['name']}!",
        f"{winner_waifu['name']} proved their strength in this intense battle!",
        f"What a fight! {winner_waifu['name']} emerged victorious!",
        f"The battlefield trembled as {winner_waifu['name']} claimed victory!"
    ]
    
    embed.set_footer(text=random.choice(battle_quotes))
    
    await ctx.send(embed=embed)

@bot.command()
async def trade(ctx, member: discord.Member = None, *, waifu_name: str = None):
    """Propose a waifu trade to another user"""
    global pending_trades
    
    if member is None or waifu_name is None:
        await ctx.send("❌ Usage: `.trade @user <waifu name>`")
        return
    
    if member.id == ctx.author.id:
        await ctx.send("❌ You can't trade with yourself!")
        return
    
    if member.bot:
        await ctx.send("❌ You can't trade with bots!")
        return
    
    user_id = str(ctx.author.id)
    target_id = str(member.id)
    
    # Check if target already has pending trade
    if target_id in pending_trades:
        await ctx.send(f"❌ {member.mention} already has a pending trade!")
        return
    
    # Find the waifu to trade
    user_waifus = data_manager.get_user_waifus(user_id)
    waifu_id = None
    waifu_data = None
    
    for wid, wdata in user_waifus.items():
        if wdata["name"].lower() == waifu_name.lower():
            waifu_id = wid
            waifu_data = wdata
            break
    
    if not waifu_id:
        await ctx.send(f"❌ You don't have a waifu named '{waifu_name}' to trade!")
        return
    
    # Create trade offer embed
    rarity_emoji = RARITY_CONFIG[waifu_data["rarity"]]["emoji"]
    embed = discord.Embed(
        title="🔄 Waifu Trade Offer",
        description=f"{member.mention}, {ctx.author.mention} wants to trade with you!",
        color=0x9370DB
    )
    
    embed.add_field(
        name="📦 Offered Character",
        value=f"**{waifu_data['name']}**\n{rarity_emoji} {waifu_data['rarity'].title()}\n⚔️ Power: {waifu_data['power']}\n📺 {waifu_data['anime']}",
        inline=False
    )
    
    embed.add_field(
        name="🤝 How to Respond",
        value="Type `.accept` to accept or `.decline` to decline!\n⏰ This offer expires in 60 seconds.",
        inline=False
    )
    
    embed.set_image(url=waifu_data["image"])
    
    trade_msg = await ctx.send(embed=embed)
    
    # Store trade offer
    pending_trades[target_id] = {
        "trader_id": user_id,
        "trader_name": ctx.author.display_name,
        "waifu_id": waifu_id,
        "waifu_data": waifu_data,
        "message": trade_msg,
        "channel": ctx.channel.id
    }
    
    # Set timeout
    await asyncio.sleep(60)
    if target_id in pending_trades:
        del pending_trades[target_id]
        try:
            await trade_msg.edit(embed=discord.Embed(
                title="💔 Trade Expired",
                description="The trade offer has expired.",
                color=0x808080
            ))
        except:
            pass

@bot.command()
async def accept(ctx):
    """Accept a pending trade offer"""
    global pending_trades
    user_id = str(ctx.author.id)
    
    if user_id not in pending_trades:
        await ctx.send("❌ You don't have any pending trade offers!")
        return
    
    trade = pending_trades[user_id]
    trader_id = trade["trader_id"]
    waifu_id = trade["waifu_id"]
    waifu_data = trade["waifu_data"]
    
    # Check if trader still has the waifu
    trader_waifus = data_manager.get_user_waifus(trader_id)
    if waifu_id not in trader_waifus:
        await ctx.send("❌ The trader no longer has this waifu!")
        del pending_trades[user_id]
        return
    
    # Get user's waifus to choose from
    user_waifus = data_manager.get_user_waifus(user_id)
    if not user_waifus:
        await ctx.send("❌ You don't have any waifus to trade!")
        del pending_trades[user_id]
        return
    
    # Show selection menu
    embed = discord.Embed(
        title="🔄 Select Your Waifu to Trade",
        description="Choose which waifu you want to trade:",
        color=0x9370DB
    )
    
    waifu_list = list(user_waifus.items())[:10]  # Show max 10
    for i, (wid, wdata) in enumerate(waifu_list, 1):
        rarity_emoji = RARITY_CONFIG[wdata["rarity"]]["emoji"]
        embed.add_field(
            name=f"{i}. {wdata['name']}",
            value=f"{rarity_emoji} {wdata['rarity'].title()} • ⚔️ {wdata['power']}",
            inline=True
        )
    
    embed.set_footer(text="Type the number of the waifu you want to trade (1-10)")
    
    await ctx.send(embed=embed)
    
    # Wait for selection
    def check_selection(message):
        return message.author == ctx.author and message.channel == ctx.channel and message.content.isdigit()
    
    try:
        selection_msg = await bot.wait_for('message', check=check_selection, timeout=30.0)
        selection = int(selection_msg.content)
        
        if selection < 1 or selection > len(waifu_list):
            await ctx.send("❌ Invalid selection!")
            return
        
        selected_waifu_id, selected_waifu_data = waifu_list[selection - 1]
        
        # Perform the trade
        data_manager.remove_waifu_from_collection(trader_id, waifu_id)
        data_manager.remove_waifu_from_collection(user_id, selected_waifu_id)
        data_manager.add_waifu_to_collection(user_id, waifu_id, waifu_data)
        data_manager.add_waifu_to_collection(trader_id, selected_waifu_id, selected_waifu_data)
        
        # Success message
        embed = discord.Embed(
            title="🎉 Trade Complete!",
            description=f"**{ctx.author.display_name}** and **{trade['trader_name']}** successfully traded waifus!",
            color=0x00FF00
        )
        
        embed.add_field(
            name=f"{trade['trader_name']} received",
            value=f"**{selected_waifu_data['name']}**",
            inline=True
        )
        
        embed.add_field(
            name=f"{ctx.author.display_name} received",
            value=f"**{waifu_data['name']}**",
            inline=True
        )
        
        await ctx.send(embed=embed)
        
    except asyncio.TimeoutError:
        await ctx.send("⏰ Trade selection timed out!")
    
    # Clean up
    if user_id in pending_trades:
        del pending_trades[user_id]

@bot.command()
async def decline(ctx):
    """Decline a pending trade offer"""
    global pending_trades
    user_id = str(ctx.author.id)
    
    if user_id not in pending_trades:
        await ctx.send("❌ You don't have any pending trade offers!")
        return
    
    trade = pending_trades[user_id]
    
    embed = discord.Embed(
        title="❌ Trade Declined",
        description=f"**{ctx.author.display_name}** declined the trade offer from **{trade['trader_name']}**.",
        color=0x808080
    )
    
    await ctx.send(embed=embed)
    del pending_trades[user_id]

# Handle gang invitation responses (merged with marriage responses above)

@bot.command()
async def profile(ctx, member: discord.Member = None):
    """Show user profile and progress"""
    try:
        if member is None:
            member = ctx.author

        user_id = str(member.id)

        # Get user data with safe type conversion
        try:
            wallet = int(data_manager.get_credits(user_id) or 0)
            bank = int(data_manager.get_bank_credits(user_id) or 0)
            total = wallet + bank
            has_shield = bool(data_manager.has_shield(user_id))
            pet = data_manager.get_user_pet(user_id)
            married_to = str(data_manager.is_married(user_id) or "")
        except (ValueError, TypeError) as e:
            logger.error(f"Error getting user data for {user_id}: {e}")
            await ctx.send("❌ Error retrieving user data. Please try again.")
            return

        # Calculate rank safely
        try:
            all_credits = data_manager.get_all_credits()
            user_totals = {}
            for uid in all_credits.keys():
                try:
                    user_wallet = int(data_manager.get_credits(str(uid)) or 0)
                    user_bank = int(data_manager.get_bank_credits(str(uid)) or 0)
                    user_totals[str(uid)] = user_wallet + user_bank
                except (ValueError, TypeError):
                    continue

            sorted_users = sorted(user_totals.items(), key=lambda x: x[1], reverse=True)
            rank = next((i+1 for i, (uid, _) in enumerate(sorted_users) if str(uid) == user_id), "Unranked")
        except Exception:
            rank = "Unranked"

        embed = discord.Embed(
            title=f"👤 {str(member.display_name)}'s Profile",
            color=0x3498DB
        )

        try:
            embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        except:
            pass  # Skip thumbnail if there's an issue

        embed.add_field(
            name="💰 Credits",
            value=f"Wallet: {wallet:,}\nBank: {bank:,}\nTotal: {total:,}",
            inline=True
        )

        embed.add_field(
            name="🏆 Rank",
            value=f"#{rank}",
            inline=True
        )

        embed.add_field(
            name="🛡️ Shield",
            value="Protected" if has_shield else "Unprotected",
            inline=True
        )

        # Pet information with safe handling
        if pet and isinstance(pet, dict):
            try:
                pet_status = "Alive" if pet.get("alive", False) else "Dead"
                pet_name = str(pet.get('name', 'Unknown'))
                pet_hp = int(pet.get('hp', 0))
                pet_max_hp = int(pet.get('max_hp', 1))
                pet_attack = int(pet.get('attack', 0))
                pet_info = f"**{pet_name}**\nHP: {pet_hp}/{pet_max_hp}\nAttack: {pet_attack}\nStatus: {pet_status}"
            except (ValueError, TypeError):
                pet_info = "Pet data corrupted"
        else:
            pet_info = "No pet owned"

        embed.add_field(
            name="🐾 Pet",
            value=pet_info,
            inline=True
        )

        # Marriage status with safe handling
        if married_to and married_to != "":
            try:
                partner = await bot.fetch_user(int(married_to))
                marriage_status = f"💍 Married to {str(partner.display_name)}"
            except:
                marriage_status = "💍 Married"
        else:
            marriage_status = "💔 Single"

        embed.add_field(
            name="💕 Relationship",
            value=marriage_status,
            inline=True
        )

        embed.add_field(
            name="📊 Bot Progress",
            value="Active Twinkii Bot user!",
            inline=True
        )

        await ctx.send(embed=embed)

    except Exception as e:
        logger.error(f"Error in profile command: {e}")
        await ctx.send("❌ Error displaying profile. Please try again.")

# Server Welcome Command
@bot.command()
async def eye(ctx, member: discord.Member = None):
    """Welcome to server vision - give a cute welcome to user"""
    if member is None:
        member = ctx.author
    
    welcome_messages = [
        f"👁️ **Server Vision Activated!** 👁️\n✨ Welcome to the server, {member.mention}! Your presence has been detected and you look absolutely adorable! 🥰",
        f"👁️ **Vision Online!** 👁️\n🌟 Aww, look who just joined! {member.mention}, you're looking super cute today! Welcome to our amazing server! 💖",
        f"👁️ **Cute Detection System Activated!** 👁️\n🎉 {member.mention} has entered the server and the cuteness levels are off the charts! Welcome aboard! 😍",
        f"👁️ **Server Radar: Cutie Detected!** 👁️\n💫 Hello there, {member.mention}! You're looking absolutely precious! Welcome to our wonderful community! 🌸",
        f"👁️ **Vision Sensors: Maximum Adorableness!** 👁️\n🎈 {member.mention}, you've just made our server 1000% cuter! Welcome, sweet soul! 💕"
    ]
    
    embed = discord.Embed(
        title="👁️ Server Vision System",
        description=random.choice(welcome_messages),
        color=0xFF69B4
    )
    
    embed.add_field(
        name="🔍 Analysis Complete",
        value=f"✅ Cuteness Level: **Maximum**\n✅ Welcome Status: **Activated**\n✅ Server Protection: **Enabled**",
        inline=False
    )
    
    embed.add_field(
        name="🎯 Server Features",
        value="• Use `.help` to see all commands\n• Join the fun with economy games\n• Collect anime waifus with `.summon`\n• Make friends and have fun!",
        inline=False
    )
    
    # Add cute anime gif
    cute_gifs = [
        "https://media.tenor.com/J5n7c4IP0b0AAAAC/anime-welcome.gif",
        "https://media.tenor.com/2Q7CwSqIhvEAAAAC/anime-wave.gif",
        "https://media.tenor.com/oyZVyQKn5A4AAAAC/anime-cute.gif",
        "https://media.tenor.com/8n3CwDTW_SsAAAAC/welcome-anime.gif",
        "https://media.tenor.com/QjPJ8KfXelEAAAAC/anime-kawaii.gif"
    ]
    
    embed.set_image(url=random.choice(cute_gifs))
    embed.set_footer(text=f"Welcome initiated by {ctx.author.display_name} • Server Vision™")
    
    await ctx.send(embed=embed)

# Adding social commands and fun analysis commands to help command.
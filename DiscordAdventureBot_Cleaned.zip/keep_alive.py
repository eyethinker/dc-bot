"""
Keep-alive web server for Replit hosting
Provides a simple HTTP endpoint to prevent the bot from sleeping
"""

from flask import Flask, render_template
import logging
import os

# Configure logging
logger = logging.getLogger(__name__)

app = Flask(__name__)

@app.route('/')
def home():
    """Main status page"""
    return render_template('index.html')

@app.route('/health')
def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "discord-bot",
        "message": "Bot is running successfully"
    }

@app.route('/ping')
def ping():
    """Simple ping endpoint"""
    return "pong"

@app.route('/status')
def status():
    """Bot status information"""
    return {
        "bot_status": "online",
        "hosting": "replit",
        "version": "1.0.0",
        "features": [
            "social_commands",
            "economy_system", 
            "flag_game",
            "gambling",
            "credit_drops"
        ]
    }

def keep_alive():
    """Start the Flask web server"""
    try:
        # Use environment variable for port, default to 5000
        port = int(os.getenv('PORT', 5000))
        
        logger.info(f"Starting keep-alive server on port {port}")
        
        # Run Flask app
        app.run(
            host='0.0.0.0',
            port=port,
            debug=False,  # Disable debug mode for production
            use_reloader=False  # Disable auto-reloader to prevent conflicts
        )
    except Exception as e:
        logger.error(f"Failed to start keep-alive server: {e}")
        raise
